import { HttpEventType } from "@angular/common/http";
import {
  Component,
  ElementRef,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
  ViewChild
} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription } from "rxjs";
import {
  ProgressStatus,
  ProgressStatusEnum
} from "src/app/model/progress-status.model";
import { NotificationService } from "src/app/notification.service";
import { SharedService } from "src/app/shared.service";
import { AuthService } from "src/app/_services/auth.service";
import Swal from "sweetalert2";
import { MatAccordion } from "@angular/material/expansion";
import { saveAs } from "file-saver-es";
import { FormControl } from "@angular/forms";
import * as moment from "moment";
import { DatePipe, DOCUMENT } from "@angular/common";
import { NgxSpinnerService } from "ngx-spinner";
@Component({
  selector: "app-operating-license",
  templateUrl: "./operating-license.component.html",
  styleUrls: ["./operating-license.component.css"]
})
export class OperatingLicenseComponent implements OnInit {
  @ViewChild(MatAccordion) accordion: MatAccordion;
  @Input() public disabled: boolean;
  @Output() public uploadStatus: EventEmitter<ProgressStatus>;
  @ViewChild("inputFile") inputFile: ElementRef;
  isClicked: boolean = false;
  typeSelected: string;
  isDone = true;
  fileName = "";
  searchText;
  Start_Date = new FormControl(new Date("yyyy-mm-dd"));
  End_Date = new FormControl(new Date("yyyy-mm-dd"));
  myDate = new Date();
  OperatingList: any;
  public form: {
    OLID: any;
    Registration_No: string;
    Product_Category: string;
    Product_Name: string;
    Registered_On: string;
    Valid_Till: string;
    Applicable_Products: string;
    Status: string;
    License_Doc: FileList | null;
    CreatedBy: string;
    PlantId: string;
    MfgName: string;
  };

  fileToUpload: any;
  BISProgramID = 0;
  isTableExpanded = false;
  searchTerm: any;
  public filterTerm!: any;
  ProductItemList: any = [];
  param: any;
  jsonParam: any = [];
  value1: any;
  target: HTMLButtonElement | undefined;
  shared: any;
  formgroup: any;
  SharedService: any;
  message: string;
  BISMasterLists: any;
  Upld_Test_Report: any;
  isActiveDiv: boolean;
  DelDataByTables: any;
  latest_date: string;
  myPastDate: Date;
  myPastDates: string;
  PlantId: string;
  OperatingMasterList: any;
  OperatingMasterLists: any;
  License_Doc: any;
  license_Doc: any;
  GetMfgList: any;
  Roleid: string;

  constructor(
    private authService: AuthService,
    private service: SharedService,
    private notifyService: NotificationService,
    private activatedRoute: ActivatedRoute,
    @Inject(DOCUMENT) private _document: Document,
    private spinnerService: NgxSpinnerService,
    private datePipe: DatePipe,
    private router: Router
  ) {
    this.uploadStatus = new EventEmitter<ProgressStatus>();

    this.form = {
      OLID: "",
      Registration_No: "",
      Product_Category: "",
      Product_Name: "",
      Registered_On: "",
      Valid_Till: "",
      Applicable_Products: "",
      Status: "",
      License_Doc: null,
      CreatedBy: "",
      PlantId: "",
      MfgName: ""
    };
  }

  public subsVar: Subscription | undefined;

  ngOnInit(): void {
    this.EnableAppHeaderMenuList();
    this.PlantId = localStorage.getItem("PlantId");
    let type = this.activatedRoute.snapshot.params["type"];
    this.Roleid = localStorage.getItem("RoleID");
    this.GetOperativeLicenseList();
    this.form.OLID = 0;
    this.GetMfgPlantList();
  }

  PostDelDataByTables(param: any) {
    this.jsonParam = {
      delId: param,
      str: "OperativeLicense"
    };
    this.service.PostDelDataByTable(this.jsonParam).subscribe(response => {
      this.DelDataByTables = response;
      console.log(this.DelDataByTables);
      if ((response.success = "DeleteSuccess")) {
        Swal.fire("Great!", "Delete Successfully!", "success");
        this.GetOperativeLicenseList();
      }
    });
  }

  EditLicenseMaster(element: any) {
    debugger;
    this.isActiveDiv = true;

    this.form.OLID = element.olid;
    this.form.Registration_No = element.registration_No;
    this.form.Product_Category = element.product_Category;
    this.form.Product_Name = element.product_Name;
    this.form.Registered_On = moment(element.registered_On).format(
      "YYYY-MM-DD"
    );
    this.form.Valid_Till = moment(element.valid_Till).format("YYYY-MM-DD");
    this.form.Applicable_Products = element.applicable_Products;
    this.form.Status = element.status;
    this.form.License_Doc = element.license_Doc;
    this.form.MfgName = element.mfgID;
  }

  GetOperativeLicenseList() {
    //
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.OperatingMasterList(this.jsonParam).subscribe(
      response => {
        this.OperatingList = response;
      },
      error => {
        this.authService.logout();
      }
    );
  }
  GetMfgPlantList() {
    //

    this.service.GetMfgPlant().subscribe(
      response => {
        this.GetMfgList = response.table;
      },
      error => {
        this.authService.logout();
      }
    );
  }

  public OperatingApplication() {
    debugger;
    var OLID = this.form.OLID;
    var Registration_No = this.form.Registration_No;
    var Product_Category = this.form.Product_Category;
    var Product_Name = this.form.Product_Name;
    var Registered_On =
      this.form.Registered_On != ""
        ? moment(this.form.Registered_On).format("YYYY-MM-DD")
        : "";
    var Valid_Till =
      this.form.Valid_Till != ""
        ? moment(this.form.Valid_Till).format("YYYY-MM-DD")
        : "";

    var Applicable_Products = this.form.Applicable_Products;
    var Status = this.form.Status;
    var MfgName = this.form.MfgName;

    var License_Doc =
      this.form.License_Doc && this.form.License_Doc.length
        ? this.form.License_Doc[0]
        : null;
    var Created_by = localStorage.getItem("name");
    var PlantId = localStorage.getItem("PlantId");

    this.service
      .OperatingApplication({
        OLID: OLID,
        Registration_No: Registration_No,
        Product_Category: Product_Category,
        Product_Name: Product_Name,
        Registered_On: Registered_On,
        Valid_Till: Valid_Till,
        Applicable_Products: Applicable_Products,
        Status: Status,
        License_Doc: License_Doc,
        MfgName: MfgName,
        CreatedBy: Created_by,
        PlantId: PlantId
      })
      .subscribe(
        data => {
          if (data) {
            console.log(data);
            switch (data.type) {
              case HttpEventType.UploadProgress:
                this.uploadStatus.emit({
                  status: ProgressStatusEnum.IN_PROGRESS,
                  percentage: Math.round((data.loaded / data.total) * 100)
                });
                break;
              case HttpEventType.Response:
                this.OperatingList = data.body;
                this.spinnerService.show();
                this.uploadStatus.emit({ status: ProgressStatusEnum.COMPLETE });

                Swal.fire("Great!", "Data Created Successfully!", "success");
                break;
            }

            this.form.Registration_No = "";
            this.form.Product_Category = "";
            this.form.Product_Name = "";
            this.form.Registered_On = "";
            this.form.Valid_Till = "";
            this.form.Applicable_Products = "";
            this.form.Status = "";
            this.form.MfgName = "";
          }
        },
        error => {
          this.inputFile.nativeElement.value = "";
          this.uploadStatus.emit({ status: ProgressStatusEnum.ERROR });
        }
      );
  }

  public upload(event) {
    if (event.target.files && event.target.files.length > 0) {
      this.fileToUpload = event.target.files[0];
      this.uploadStatus.emit({ status: ProgressStatusEnum.START });
    }
  }

  uploadfile() {
    this.service.uploadFile(this.fileToUpload).subscribe(
      data => {
        if (data) {
          switch (data.type) {
            case HttpEventType.UploadProgress:
              this.uploadStatus.emit({
                status: ProgressStatusEnum.IN_PROGRESS,
                percentage: Math.round((data.loaded / data.total) * 100)
              });
              break;
            case HttpEventType.Response:
              this.inputFile.nativeElement.value = "";
              this.uploadStatus.emit({ status: ProgressStatusEnum.COMPLETE });
              break;
          }
        }
      },
      error => {
        this.inputFile.nativeElement.value = "";
        this.uploadStatus.emit({ status: ProgressStatusEnum.ERROR });
      }
    );
  }
  Download(fileName: any, Str: any): void {
    this.jsonParam = {
      fileName: fileName,
      Str: Str
    };

    this.service
      .DownloadFile(this.jsonParam)
      .subscribe(blob => saveAs(blob, fileName));
  }
  handleClear() {
    this.form.Registration_No = "";
    this.form.Product_Category = "";
    this.form.Product_Name = "";
    this.form.Registered_On = "";
    this.form.Valid_Till = "";
    this.form.Applicable_Products = "";
    this.form.Status = "";
    this.form.MfgName = "";
  }
  resetForm() {

    this.GetMfgPlantList();
   
    
    this.form = {
      OLID: "",
      Registration_No: "",
      Product_Category: "",
      Product_Name: "",
      Registered_On: "",
      Valid_Till: "",
      Applicable_Products: "",
      Status: "",
      License_Doc: null,
      CreatedBy: "",
      PlantId: "",
      MfgName: ""
    };

    
  }
  EnableAppHeaderMenuList() {
    this.service.EnableHeaderMenuList();
  }
  home() {
    this.router.navigate(["/dashboard"]);
  }

  disableSwitching: boolean;
  @ViewChild("tabset") tabset: any;

  ngAfterViewInit() {
    console.log(this.tabset.tabs);
  }

  goto(id) {
    this.tabset.tabs[id].active = true;
  }

  changeTab() {
    this.tabset.select(String(Number(this.tabset.activeId) + 1));
  }
  downloadFile() {
    this.license_Doc.download().subscribe(
      res => {
        const blob = new Blob([res.blob()], {
          type: "application/vnd.ms.excel"
        });
        const file = new File([blob], this.fileName + ".xlsx", {
          type: "application/vnd.ms.excel"
        });
      },
      res => {}
    );
  }
}
