import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BisQueryComponent } from './bis-query.component';

describe('BisQueryComponent', () => {
  let component: BisQueryComponent;
  let fixture: ComponentFixture<BisQueryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BisQueryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BisQueryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
