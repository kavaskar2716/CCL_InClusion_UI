import { HttpEventType } from "@angular/common/http";
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild
} from "@angular/core";
import { FormControl } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import * as moment from "moment";
import { Subscription } from "rxjs";
import {
  ProgressStatus,
  ProgressStatusEnum
} from "src/app/model/progress-status.model";
import { NotificationService } from "src/app/notification.service";
import { SharedService } from "src/app/shared.service";
import { AuthService } from "src/app/_services/auth.service";
import { MatAccordion } from "@angular/material/expansion";
import Swal from "sweetalert2";
import { saveAs } from "file-saver-es";
//import { exit } from "process";

@Component({
  selector: "app-bis-query",
  templateUrl: "./bis-query.component.html",
  styleUrls: ["./bis-query.component.css"]
})
export class BisQueryComponent implements OnInit {
  @Input() public disabled: boolean;
  @ViewChild("Upload_QuotationRef") inputvar1: ElementRef;
  @ViewChild("Upload_PO_ReferenceRef") inputvar2: ElementRef;
  @ViewChild("Upload_InvoiceRef") inputvar3: ElementRef;
  @ViewChild(MatAccordion) accordion: MatAccordion;
  @Output() public uploadStatus: EventEmitter<ProgressStatus>;
  @ViewChild("inputFile") inputFile: ElementRef;
  OperatingList: any;
  searchText;
  public form: {
    QryID: any;
    QryDate: any;
    QueryBy:string;
    Query_Related_To:string;
    QueryTo:string;
    QuerySubject:string;
    Product:string;
    Model_For_BISs:string;
    Inclusion_RequestID:string;
    Query_One:string;
    Query_One_Date: any;
    Query1_Reply_From_Lnv:string;
    Query1_Reply_Date:any;
    Query_Two:string;
    Query_Two_Date: any;
    Query2_Reply_From_Lnv:string;
    Query2_Reply_Date:any;
    Query_Three:string;
    Query_Three_Date: any;
    Query3_Reply_From_Lnv:string;
    Query3_Reply_Date:any;
    CreatedBy:string;
    Query_Status:any;
    MfgPlantID:any;
    PlantId:any


    
  };
  Query1_Date = new FormControl(new Date("yyyy-mm-dd"));
  Query2_Date = new FormControl(new Date("yyyy-mm-dd"));
  Query3_Date = new FormControl(new Date("yyyy-mm-dd"));

  Query1_Reply_Date = new FormControl(new Date("yyyy-mm-dd"));
  Query2_Reply_Date = new FormControl(new Date("yyyy-mm-dd"));
  Query3_Reply_Date = new FormControl(new Date("yyyy-mm-dd"));

  searchTerm: any;
  status: any = "";
  shared: any;
  jsonParam: any = [];
  formgroup: any;
  SharedService: any;
  message: string;
  isActiveDiv: boolean;
  OperatingMasterLists: any;
  fileName: string;
  License_Doc: any;
  OperatingMasterList: void;
  DelDataByTables: any;
  POMasterList: any;
  POMasterLists: any;
  PlantId: string;
  Upload_Quotation: any;
  Upload_PO_Reference: any;
  Upload_Invoice: any;
  Roleid: string;
  GetBISProduct: any;
  BISProduct: any;
  BISModel: any;
  BISSeries: any;
  BISCategory: any;
  BISYear: any;
  BISMfg: any;
  GetMfgList: any;
  GetBISProductListByParam: any;
  POMasterINDLists: any;
  Inclusionid: any;
  BISInclusion: any;
  BISModels: any;
  public Incagents : InclusionAgent[];
  public ProdAgent : ProductAgent[];
  public BISModelAgent : BISModelAgent[];
  constructor(
    private authService: AuthService,
    private service: SharedService,
    private notifyService: NotificationService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {
    this.uploadStatus = new EventEmitter<ProgressStatus>();

    let Incagents :InclusionAgent[]= []; 
    this.Incagents = Incagents; 

    let ProdAgent :ProductAgent[]= []; 
    this.ProdAgent = ProdAgent; 

    let BISModelAgent :BISModelAgent[]= []; 
    this.BISModelAgent = BISModelAgent; 

    this.form = {
      QryID:"",
      // MfgPlantID: 1,

      QryDate:"",
      QueryBy:"",
      Query_Related_To:"",
      QueryTo:"",
      QuerySubject:"",
      Product:"",
      Model_For_BISs:"",
      Inclusion_RequestID:"",
      Query_One:"",
      Query_One_Date: "",
      Query1_Reply_From_Lnv:"",
      Query1_Reply_Date:"",
      Query_Two:"",
      Query_Two_Date: "",
      Query2_Reply_From_Lnv:"",
      Query2_Reply_Date:"",
      Query_Three:"",
      Query_Three_Date: "",
      Query3_Reply_From_Lnv:"",
      Query3_Reply_Date:"",
      CreatedBy:"",
      Query_Status:"",
      MfgPlantID:"",
      PlantId:""
    };
  }

  public subsVar: Subscription | undefined;


  ngOnInit(): void {
    this.GetMfgPlantList();

    this.EnableAppHeaderMenuList();
    this.PlantId = localStorage.getItem("PlantId");
    this.InclusionCategoryProductFilter();
    let type = this.activatedRoute.snapshot.params["type"];
    this.Roleid = localStorage.getItem("RoleID");
    this.GetBisQueryLists();
    this.form.QryID = 0;
    this.form.Query_Status="Open";
    this.form.MfgPlantID = 1;

    this.service.QueryMasterList(this.jsonParam).subscribe(response => {
      this.POMasterLists = response.table;
    });
  }

  InclusionCategoryProductFilter() {
    debugger;
    this.jsonParam = {
      plantId: localStorage.getItem("PlantId"),
       mfgPlantId:1
    };

    this.service.GetBISInclusionList(this.jsonParam).subscribe(response => {
      debugger;
      this.GetBISProduct = response;

      this.BISInclusion = this.GetBISProduct.table;
      this.BISProduct = this.GetBISProduct.table1;
      this.BISModel = this.GetBISProduct.table2;

      
      console.log(this.BISInclusion);
      console.log(this.BISProduct);
      console.log(this.BISModel);

      console.log(response);
    });
  }
  GetMfgPlantList() {
   
    this.service.GetMfgPlant().subscribe(
      response => {
        debugger
        this.GetMfgList = response.table;
        this.form.MfgPlantID = 1;
        this.form.Query_Status="Open";
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetKeyFiltersBy_InclusionID() {
    debugger;
   // this.form.Model_For_BIS = "";
   if (this.form.Inclusion_RequestID != '')
   {
    
    this.jsonParam = {
    
      Inclusion_Request_Id: this.form.Inclusion_RequestID,
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };
    debugger;
    this.service.GetBISQueryFilterByInclusionID(this.jsonParam).subscribe(
      response => {
        debugger;
 
         this.BISProduct = response.table;
         this.BISModel = response.table1;

        this.form.Product = response.table[0].product;
        this.form.Model_For_BISs = response.table1[0].model_For_BISs;

        console.log(response);
      },
      error => {
        this.authService.logout();
      }
    );
   }
   else{    
    this.form.Product = '';
    this.form.Model_For_BISs = '';}
  }


  GetKeyFiltersBy_Product1() {
    debugger;
   // this.form.Model_For_BIS = "";

    this.jsonParam = {
    
      product: this.form.Product,
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };
    debugger;
    this.service.GetBISPOModelList(this.jsonParam).subscribe(
      response => {
        debugger;
        this.GetBISProductListByParam = response;
        this.BISModel = this.GetBISProductListByParam.table;
        
      },
      error => {
        this.authService.logout();
      }
    );
  }
  GetKeyFiltersBy_category() {
    debugger;
    this.form.Product = "";

    this.jsonParam = {
      Category: "",
      product: "",
      modelForBis: "",
      seriesModel: "",
      status: "",
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };
    debugger;
    this.service.GetBISKeyFiltersBy_Param(this.jsonParam).subscribe(
      response => {
        debugger;
        this.GetBISProductListByParam = response;
        this.BISProduct = this.GetBISProductListByParam.table2;
        this.BISModel = this.GetBISProductListByParam.table3;
        this.BISSeries = this.GetBISProductListByParam.table4;

        console.log(this.BISProduct);
        console.log(this.BISModel);
        console.log(this.BISSeries);

        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetBisQueryLists() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.QueryMasterList(this.jsonParam).subscribe(response => {
      this.POMasterLists = response.table;
    });
  }

  EditPOMaster(element: any) {
    debugger;
   // this.InclusionCategoryProductFilter();

      this.Incagents.splice(0);
      this.BISInclusion.splice(0);
      let pusheditems1 = {};
    
      pusheditems1['inclusion_Request_Id'] = element.inclusion_RequestID;
      this.Incagents.push(<InclusionAgent>{ inclusion_Request_Id:pusheditems1['inclusion_Request_Id']});
      this.BISInclusion = this.Incagents;
      console.log(this.BISInclusion);

      this.ProdAgent.splice(0);
      this.BISProduct.splice(0);
      let pusheditems2 = {};

      pusheditems2['product'] = element.product;
      this.ProdAgent.push(<ProductAgent>{ product:pusheditems2['product']});
      this.BISProduct = this.ProdAgent;
      console.log(this.BISProduct);
      
      this.BISModelAgent.splice(0);
      this.BISModel.splice(0);
      let pusheditems3 = {};

      pusheditems3['model_For_BISs'] = element.model_For_BIS;
      this.BISModelAgent.push(<BISModelAgent>{ model_For_BISs:pusheditems3['model_For_BISs']});
      this.BISModel = this.BISModelAgent;
      console.log(this.BISModel);



    this.isActiveDiv = true;
    this.form.QryID = element.qryID;
    this.form.QryDate = element.qryDate;
    this.form.QueryBy=element.queryBy
    this.form.Query_Related_To = element.query_Related_To;
    //this.form.Lead_Model = element.lead_Model;
    this.form.QueryTo = element.queryTo;
    this.form.QuerySubject = element.querySubject;
    this.form.Product = element.product;
    this.form.Model_For_BISs = element.model_For_BIS;
    this.form.Inclusion_RequestID = element.inclusion_RequestID;
    this.form.Query_One = element.query_One;
    this.form.Query_One_Date = element.query_One_Date;
    this.form.Query1_Reply_From_Lnv = element.query1_Reply_From_Lnv;
    this.form.Query1_Reply_Date = element.query1_Reply_Date;
    this.form.Query_Two = element.query_Two;
    this.form.Query_Two_Date = element.query_Two_Date;
    this.form.Query2_Reply_From_Lnv = element.query2_Reply_From_Lnv;
    this.form.Query2_Reply_Date = element.query2_Reply_Date;
    this.form.Query_Three = element.query_Three;
    this.form.Query_Three_Date = element.query_Three_Date;
    this.form.Query3_Reply_From_Lnv = element.query3_Reply_From_Lnv;
    this.form.Query3_Reply_Date = element.query3_Reply_Date;
    this.form.Query_Status = element.query_Status;

    // this.form.PlantId = element.plantId;
  }

  PostDelDataByTables(param: any) {
    this.jsonParam = {
      delId: param,
      str: "BISQuery",
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.PostDelDataByTable(this.jsonParam).subscribe(response => {
      this.DelDataByTables = response;
      console.log(this.DelDataByTables);
      if ((response.success = "DeleteSuccess")) {
        Swal.fire("Great!", "Delete Successfully!", "success");
        this.GetBisQueryLists();
      }
    });
  }

  public QueryApplication() {
    debugger;
    var QryID = this.form.QryID;
    var QryDate = this.form.QryDate;
    var QueryBy = this.form.QueryBy;
    // var Lead_Model = this.form.Lead_Model;
    var Query_Related_To = this.form.Query_Related_To;
    var QueryTo = this.form.QueryTo;
    var QuerySubject = this.form.QuerySubject;
    var Product = this.form.Product;
    var Model_For_BIS = this.form.Model_For_BISs;
    var Inclusion_RequestID = this.form.Inclusion_RequestID;
    // var Query_One = this.form.Query_One;
    var Query_One = this.form.Query_One != null
    ? this.form.Query_One
    : "";
    var Query_One_Date =  this.form.Query_One_Date != ""
    ? moment(this.form.Query_One_Date).format("YYYY-MM-DD")
    : "";
    // var Query1_Reply_From_Lnv = this.form.Query1_Reply_From_Lnv;
    var Query1_Reply_From_Lnv = this.form.Query1_Reply_From_Lnv != null
    ? this.form.Query1_Reply_From_Lnv
    : "";
    var Query1_Reply_Date =  this.form.Query1_Reply_Date != ""
    ? moment(this.form.Query1_Reply_Date).format("YYYY-MM-DD")
    : "";
    // var Query_Two = this.form.Query_Two;
    var Query_Two = this.form.Query_Two != null
    ? this.form.Query_Two
    : "";
    var Query_Two_Date =  this.form.Query_Two_Date != ""
    ? moment(this.form.Query_Two_Date).format("YYYY-MM-DD")
    : "";
    var Query2_Reply_From_Lnv = this.form.Query2_Reply_From_Lnv != null
    ? this.form.Query2_Reply_From_Lnv
    : "";
    var Query2_Reply_Date =  this.form.Query2_Reply_Date != ""
    ? moment(this.form.Query2_Reply_Date).format("YYYY-MM-DD")
    : "";
    // var Query2_Reply_From_Lnv = this.form.Query2_Reply_From_Lnv;
   // var Query_Three = this.form.Query_Three;
   var Query_Three = this.form.Query_Three != null
   ? this.form.Query_Three
   : "";
    var Query_Three_Date =  this.form.Query_Three_Date != ""
    ? moment(this.form.Query_Three_Date).format("YYYY-MM-DD")
    : "";
    // var Query3_Reply_From_Lnv = this.form.Query3_Reply_From_Lnv;
    var Query3_Reply_From_Lnv = this.form.Query2_Reply_From_Lnv != null
    ? this.form.Query3_Reply_From_Lnv
    : "";
    var Query3_Reply_Date =  this.form.Query3_Reply_Date != ""
    ? moment(this.form.Query3_Reply_Date).format("YYYY-MM-DD")
    : "";
    var Query_Status=this.form.Query_Status;
    var CreatedBy = localStorage.getItem("name");
   
    var PlantId = localStorage.getItem("PlantId");
    var MfgPlantID = 1;

    this.service.QueryApplication({
      QryID: QryID,
      QryDate: QryDate,
      QueryBy: QueryBy,
      Query_Related_To: Query_Related_To,
      QueryTo: QueryTo,
      QuerySubject: QuerySubject,
      Product: Product,
      Model_For_BIS: Model_For_BIS,
      Inclusion_RequestID: Inclusion_RequestID,
      Query_One: Query_One,
      Query_One_Date: Query_One_Date,
      Query1_Reply_From_Lnv: Query1_Reply_From_Lnv,
      Query1_Reply_Date:Query1_Reply_Date,
      Query_Two: Query_Two,
      Query_Two_Date: Query_Two_Date,
      Query2_Reply_From_Lnv: Query2_Reply_From_Lnv,
      Query2_Reply_Date:Query2_Reply_Date,
      Query_Three: Query_Three,
      Query_Three_Date: Query_Three_Date,
      Query3_Reply_From_Lnv: Query3_Reply_From_Lnv,
      Query3_Reply_Date:Query3_Reply_Date,
      CreatedBy: CreatedBy,
      PlantId: PlantId,
      MfgPlantID:MfgPlantID,
      Query_Status:Query_Status
     
    })
      .subscribe(
        data => {
          if (data) {
            console.log(data);
            debugger;
            switch (data.type) {
              case HttpEventType.UploadProgress:
                this.uploadStatus.emit({
                  status: ProgressStatusEnum.IN_PROGRESS,
                  percentage: Math.round((data.loaded / data.total) * 100)
                });
                break;
              case HttpEventType.Response:
                this.POMasterLists = data.body;

                this.uploadStatus.emit({ status: ProgressStatusEnum.COMPLETE });

                Swal.fire("Great!", "Data Created Successfully!", "success");
                break;
            }
            Swal.fire("Great!", "Data Created Successfully!", "success");

            this.GetBisQueryLists();

           this.form.QryID="";
           this.form.QryDate="";
           this.form.QueryBy="";
           this.form.Query_Related_To="";
           this.form.QueryTo="";
           this.form.QuerySubject="";
           this.form.Product="";
           this.form.Model_For_BISs="";
           this.form.Inclusion_RequestID="";
           this.form.Query_One="";
           this.form.Query_One_Date="";
           this.form.Query1_Reply_From_Lnv="";
           this.form.Query_Two="";
           this.form.Query_Two_Date="";
           this.form.Query2_Reply_From_Lnv="";
           this.form.Query_Three="";
           this.form.Query_Three_Date="";
           this.form.Query3_Reply_From_Lnv="";
          
     
          }
        },
        error => {
          this.inputFile.nativeElement.value = "";
          this.uploadStatus.emit({ status: ProgressStatusEnum.ERROR });
        }
      );
  }

 


  EnableAppHeaderMenuList() {
    this.service.EnableHeaderMenuList();
  }
  home() {
    this.router.navigate(["/dashboard"]);
  }

  ngAfterViewInit() {}
  Download(fileName: any, Str: any): void {
    debugger;
    this.jsonParam = {
      fileName: fileName,
      Str: Str
    };

    this.service
      .DownloadFile(this.jsonParam)
      .subscribe(blob => saveAs(blob, fileName));
  }
  downloadFile() {
    this.Upload_Quotation.download().subscribe(
      res => {
        const blob = new Blob([res.blob()], {
          type: "application/vnd.ms.excel"
        });
        const file = new File([blob], this.fileName + ".xlsx", {
          type: "application/vnd.ms.excel"
        });
      },
      res => {}
    );
    this.Upload_PO_Reference.download().subscribe(
      res => {
        const blob = new Blob([res.blob()], {
          type: "application/vnd.ms.excel"
        });
        const file = new File([blob], this.fileName + ".xlsx", {
          type: "application/vnd.ms.excel"
        });
      },
      res => {}
    );
    this.Upload_Invoice.download().subscribe(
      res => {
        const blob = new Blob([res.blob()], {
          type: "application/vnd.ms.excel"
        });
        const file = new File([blob], this.fileName + ".xlsx", {
          type: "application/vnd.ms.excel"
        });
      },
      res => {}
    );
  }
  resetForm() {

    this.GetMfgPlantList();
    this.InclusionCategoryProductFilter();
    
    this.form = {
      QryID:0,
      QryDate:"",
      QueryBy:"",
      Query_Related_To:"",
      QueryTo:"",
      QuerySubject:"",
      Product:"",
      Model_For_BISs:"",
      Inclusion_RequestID:"",
      Query_One:"",
      Query_One_Date: "",
      Query1_Reply_Date:"",
      Query2_Reply_Date:"",
      Query3_Reply_Date:"",
      Query1_Reply_From_Lnv:"",
      Query_Two:"",
      Query_Two_Date: "",
      Query2_Reply_From_Lnv:"",
      Query_Three:"",
      Query_Three_Date: "",
      Query3_Reply_From_Lnv:"",
      CreatedBy:"",
      Query_Status:"",
      MfgPlantID:1,
      PlantId:""
    };

    
    // this.form.QryID=0;
    // this.form.QryDate="";
    // this.form.QueryBy="";
    // this.form.Query_Related_To="";
    // this.form.QueryTo="";
    // this.form.QuerySubject="";
   // this.form.Product="";
    //this.form.Model_For_BISs="";
   // this.form.Inclusion_RequestID="";
    // this.form.Query_One="";
    // this.form.Query_One_Date="";
    // this.form.Query1_Reply_From_Lnv="";
    // this.form.Query_Two="";
    // this.form.Query_Two_Date="";
    // this.form.Query2_Reply_From_Lnv="";
    // this.form.Query_Three="";
    // this.form.Query_Three_Date="";
    // this.form.Query3_Reply_From_Lnv="";

    console.log(this.form);
  }

}

export class InclusionAgent{
  inclusion_Request_Id: any;
}
export class ProductAgent{
  product: any;
}

export class BISModelAgent{
  model_For_BISs: any;
}
