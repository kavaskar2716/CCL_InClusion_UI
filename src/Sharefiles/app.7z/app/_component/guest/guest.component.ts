
import { Component,OnInit,HostListener, Inject, ViewChild, ElementRef  } from '@angular/core';
import { AuthService } from 'src/app/_services/auth.service';
import {Observable,Subscription,of,throwError} from 'rxjs';
import { NotificationService } from 'src/app/notification.service'
import {SharedService} from 'src/app/shared.service';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { ActivatedRoute } from '@angular/router';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-guest',
  templateUrl: './guest.component.html',
  styleUrls: ['./guest.component.css']
})
export class GuestComponent implements OnInit {
  searchTerm: any;
  public filterTerm!: any ; 
  ProductItemList: any = [];
  param: any;
  BISGrantedList: any;
  BISLabTestReportList: any;
  BISPendingList: any;
  jsonParam: any = [];
  ProductType: string = '';
  ProductItemLists: any = [];
  ResProductFilterList: any = [];
  value1: any;
  target: HTMLButtonElement | undefined;
  ProdComplainenceLists: any = [];
  ProdMachineTypeLists: any = [];
  ProdMarketingSeriesLists: any = [];
  compid: any = "";
  machineid: any = "";
  marketingid: any = "";
  categoryid: any = "";
  status: any = "";
  machineDisabled: boolean = false;
  msDisabled: boolean = false;
  compDisabled : boolean = false;
  stsDisabled : boolean = false;
  BISMasterLists: any;
  table: any;
  Productdata: any;
  GetBISProduct: any;
  BISProduct: any;
  BISProduct1: any;
  BISProduct2: any;
  ProductTypeNote: string;
  typee: string;
  category: any;
  BISModel: any;
  BISLead: any;
  BISStatus: any;
  BISSeries: any;
  BISCategory: any;
  seriesModel:any;
  model_For_BIS:any;
  product:any;
  form: any;


  constructor(
    private authService: AuthService,
    private service:SharedService,
    private notifyService : NotificationService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
  ) { 

    this.form = {     
          category:"",
          product:"",
          model_For_BIS:"",
          series_Model:"",
          status:"",
          PlantId: ""
		};
  }

  public subsVar: Subscription | undefined;
  BISProgramMasterLists() {

    this.jsonParam ={
      PlantId: localStorage.getItem('PlantId'),
  
    }
        this.service.BISProgramMasterList(this.jsonParam).subscribe(response => {

    
         this.ProductItemList = response;
       
          console.log(this.ProductItemList);
      }, error => {
        this.authService.logout();
      });
    
      }
        TradingProductFilter(param : string) {
    debugger
        this.jsonParam ={
          PlantId: 3
        }
    
    this.service.TradeProductFilters(this.jsonParam)
    .subscribe(response => {
      debugger
      this.GetBISProduct = response;
 
      this.BISProduct = this.GetBISProduct.table;
      this.BISModel = this.GetBISProduct.table1;
      this.BISSeries = this.GetBISProduct.table2;
      this.BISStatus = this.GetBISProduct.table3;
      this.BISCategory = this.GetBISProduct.table4;
      console.log(this.GetBISProduct);
   
     

    });
  }


  GrantedandLabMasterLists() {  
    this.jsonParam ={
      PlantId: localStorage.getItem('PlantId'),
  
    }
    this.service.GrantedandLabMasterList(this.jsonParam)
     .subscribe(response => {
       this.BISGrantedList = response.responseGrantedReports;
       this.BISLabTestReportList = response.responseLabTestReports;
       debugger
       console.log(this.BISGrantedList);
       console.log(this.BISLabTestReportList);
       
     });
  
  }
  GetBISPendingInclusions() {  
    this.jsonParam ={
      PlantId: localStorage.getItem('PlantId'),
  
    }
    debugger
    this.service.GetBISPendingInclusion(this.jsonParam)
     .subscribe(response => {
       this.BISPendingList = response;
     
       debugger
       console.log(this.BISPendingList);
      
       
     });
  
  }
  ngOnInit(): void {
   
    this.GetBISPendingInclusions();
    this.GrantedandLabMasterLists();
     this.EnableAppHeaderMenuList();
     this.TradingProductFilter(this.jsonParam);
     this.BISProduct();
     this.BISCategory();
      this.BISModel();
      this.BISSeries();
      this.BISStatus();

   
    if (this.service.subsVar) {    
      this.subsVar = this.service.invokeProductCategoryFunction.subscribe((param:string) => {    
   
      });    
    }
   
 

  }
  
  onfilter(){


    this.jsonParam ={
          category:this.form.category,
          product:this.form.product,
          model_For_BIS:this.form.model_For_BIS,
          series_Model:this.form.series_Model,
          status:this.form.status,
          PlantId: localStorage.getItem('PlantId')
    }
debugger
      this.service.TradingByFilters(this.jsonParam).subscribe(response => {
      this.ProductItemList = response.table;
      this.ProductItemLists = this.ProductItemList;
      console.log(this.ProductItemList);
    this.form.nativeElement.value = ' ';

    } , error => {
      this.authService.logout();
    });

   }
  marketingfilter(_marketing: any){

    this.machineDisabled = true;
    this.compDisabled = true;
    this.stsDisabled = true; 

    this.jsonParam ={
      product: _marketing,
      PlantId: localStorage.getItem('PlantId')
    }

      this.service.TradingByFilters(this.jsonParam).subscribe(response => {
      this.ProductItemList = response.table;
      this.ProductItemLists = this.ProductItemList;
      console.log(this.ProductItemList);
    } , error => {
      this.authService.logout();
    });

   }
  compfilter(compid: any){

    this.machineDisabled = true;
    this.msDisabled = true;
    this.stsDisabled = true;

    this.jsonParam ={
      SearchStr: compid,
      Str: 'COM',
      PlantId: localStorage.getItem('PlantId')
    }

      this.service.ProductByFilters(this.jsonParam).subscribe(response => {
      this.ProductItemList = response.table;
      this.ProductItemLists = this.ProductItemList;
      console.log(this.ProductItemList);
    } , error => {
      this.authService.logout();
    });

  }

  machinefilter(_machine: any){

    this.compDisabled = true;
    this.msDisabled = true; 
    this.stsDisabled = true;

    this.jsonParam ={
      SearchStr: _machine,
      Str: 'SM',
      PlantId: localStorage.getItem('PlantId')
    }

      this.service.ProductByFilters(this.jsonParam).subscribe(response => {
      this.ProductItemList = response.table;
      this.ProductItemLists = this.ProductItemList;
      console.log(this.ProductItemList);
    } , error => {
      this.authService.logout();
    });
   }


   statusfilter(status: any){

    this.machineDisabled = true;
    this.compDisabled = true;
    this.msDisabled = true;  

    this.jsonParam ={
      SearchStr: status,
      Str: 'STATUS',
      PlantId: localStorage.getItem('PlantId')
    }
    this.service.ProductByFilters(this.jsonParam)
    .subscribe(response => {
      debugger
      this.ProductItemList = response.table;
      this.ProductItemLists = this.ProductItemList;
      console.log(this.ProductItemList);
    });
     

      
   }

  EnableAppHeaderMenuList(){
    this.service.EnableHeaderMenuList();   
  }
  home()
  {
      this.router.navigate(['/dashboard']);  
  }

  ClearFilter()
  {
    this.machineDisabled = false;
    this.compDisabled = false;
    this.msDisabled = false; 
    this.stsDisabled = false; 

  this.compid = "";
  this.machineid = "";
  this.marketingid = "";
  this.status = "";

    this.ProductItemList = null;
  }



  @ViewChild('TABLE', { static: false }) TABLE: ElementRef;  
  title = 'Excel';  
  ExportTOExcel() {  
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.TABLE.nativeElement);  
    const wb: XLSX.WorkBook = XLSX.utils.book_new();  
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');  
    XLSX.writeFile(wb, 'Excelreport.xlsx');  
    
  } 

}


