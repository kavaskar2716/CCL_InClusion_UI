import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BisGrantedComponent } from './bis-granted.component';

describe('BisGrantedComponent', () => {
  let component: BisGrantedComponent;
  let fixture: ComponentFixture<BisGrantedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BisGrantedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BisGrantedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
