import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild
} from "@angular/core";

import {
  animate,
  state,
  style,
  transition,
  trigger
} from "@angular/animations";
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription } from "rxjs";
import { AuthService } from "src/app/_services/auth.service";
import { SharedService } from "src/app/shared.service";
import { NotificationService } from "src/app/notification.service";
import {
  ProgressStatus,
  ProgressStatusEnum
} from "src/app/model/progress-status.model";
import { HttpEventType } from "@angular/common/http";
import Swal from "sweetalert2";

@Component({
  selector: "app-bis-granted",
  templateUrl: "./bis-granted.component.html",
  styleUrls: ["./bis-granted.component.css"],
  animations: [
    trigger("detailExpand", [
      state("collapsed", style({ height: "0px", minHeight: "0" })),
      state("expanded", style({ height: "*" })),
      transition(
        "expanded <=> collapsed",
        animate("225ms cubic-bezier(0.4, 0.0, 0.2, 1)")
      )
    ])
  ]
})
export class BisGrantedComponent implements OnInit {
  @Input() public disabled: boolean;
  @Output() public uploadStatus: EventEmitter<ProgressStatus>;
  @ViewChild("inputFile") inputFile: ElementRef;
  OperatingList: any;
  fileToUpload: any;
  shared: any;
  formgroup: any;
  SharedService: any;
  message: string;
  jsonParam: any = [];
  isActiveDiv: boolean;
  BISGrantedList: any;
  BISLabTestReportList: any;
  BISGetGrantedList: any;
  BISGetLabTestReportList: any;
  GrantedReportByDaysList: any;
  LapTestReportByDaysList: any;
  PlantId: string;

  constructor(
    private authService: AuthService,
    private service: SharedService,
    private notifyService: NotificationService,
    private activatedRoute: ActivatedRoute,

    private router: Router
  ) {
    this.uploadStatus = new EventEmitter<ProgressStatus>();
  }
  public subsVar: Subscription | undefined;

  ngOnInit(): void {
    this.EnableAppHeaderMenuList();
    this.PlantId = localStorage.getItem("PlantId");
    let type = this.activatedRoute.snapshot.params["type"];
    this.GrantedandLabMasterLists();
  }

  GrantedandLabMasterLists() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.GrantedandLabMasterList(this.jsonParam).subscribe(response => {
      this.BISGrantedList = response.responseGrantedReports;
      this.BISLabTestReportList = response.responseLabTestReports;
      debugger;
      console.log(this.BISGrantedList);
      console.log(this.BISLabTestReportList);
    });
  }
  GetBISGrantedReportByDays(param: any) {
    this.jsonParam = {
      agingDays: param,
      PlantId: localStorage.getItem("PlantId")
    };
    this.service
      .GetBISGrantedReportByDays(this.jsonParam)
      .subscribe(response => {
        this.GrantedReportByDaysList = response;

        debugger;
        console.log(this.GrantedReportByDaysList);
      });
  }

  GetLabTestListReportByDays(param: any) {
    this.jsonParam = {
      agingDays: param,
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.GetLabTestReportByDays(this.jsonParam).subscribe(response => {
      this.LapTestReportByDaysList = response;

      debugger;
      console.log(this.LapTestReportByDaysList);
    });
  }

  public upload(event) {
    if (event.target.files && event.target.files.length > 0) {
      this.fileToUpload = event.target.files[0];
      this.uploadStatus.emit({ status: ProgressStatusEnum.START });
    }
  }

  uploadfile() {
    debugger;
    this.service.uploadFile(this.fileToUpload).subscribe(
      data => {
        if (data) {
          switch (data.type) {
            case HttpEventType.UploadProgress:
              this.uploadStatus.emit({
                status: ProgressStatusEnum.IN_PROGRESS,
                percentage: Math.round((data.loaded / data.total) * 100)
              });
              break;
            case HttpEventType.Response:
              this.inputFile.nativeElement.value = "";
              this.uploadStatus.emit({ status: ProgressStatusEnum.COMPLETE });
              break;
          }
        }
      },
      error => {
        this.inputFile.nativeElement.value = "";
        this.uploadStatus.emit({ status: ProgressStatusEnum.ERROR });
      }
    );
  }

  EnableAppHeaderMenuList() {
    this.service.EnableHeaderMenuList();
  }
  home() {
    this.router.navigate(["/dashboard"]);
  }

  ngAfterViewInit() {}
}
