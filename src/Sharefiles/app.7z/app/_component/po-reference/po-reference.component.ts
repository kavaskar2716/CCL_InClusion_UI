import { HttpEventType } from "@angular/common/http";
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild
} from "@angular/core";
import { FormControl } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import * as moment from "moment";
import { Subscription } from "rxjs";
import {
  ProgressStatus,
  ProgressStatusEnum
} from "src/app/model/progress-status.model";
import { NotificationService } from "src/app/notification.service";
import { SharedService } from "src/app/shared.service";
import { AuthService } from "src/app/_services/auth.service";
import { MatAccordion } from "@angular/material/expansion";
import Swal from "sweetalert2";
import { saveAs } from "file-saver-es";
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { array, object } from "@amcharts/amcharts5";
import { values } from "lodash";

@Component({
  selector: "app-po-reference",
  templateUrl: "./po-reference.component.html",
  styleUrls: ["./po-reference.component.css"]
})
export class PoReferenceComponent implements OnInit {
  @Input() public disabled: boolean;
  @ViewChild("Upload_QuotationRef") inputvar1: ElementRef;
  @ViewChild("Upload_PO_ReferenceRef") inputvar2: ElementRef;
  @ViewChild("Upload_InvoiceRef") inputvar3: ElementRef;
  @ViewChild(MatAccordion) accordion: MatAccordion;
  @Output() public uploadStatus: EventEmitter<ProgressStatus>;
  @ViewChild("inputFile") inputFile: ElementRef;

/* Declare Multiselect Variable */ 
  dropdownList = [];
  selectedItems = [];
  dropdownSettings:IDropdownSettings={};
/* END */ 

  OperatingList: any;
  searchText;
  public form: {
    POID: any;
    MfgPlantID: any;
    MfgPlant1ID: any;
    PO_Type: any;
 
    Category: string;
    Product: string;
    Lead_Model: string;
    Model_for_BIS: any;
    Supplier_Name: string;
    Quotation_Reference_No: string;
    Quotation_Date: string;
    PO_Reference_No: string;
    PO_Value_in_INR: any;
    PO_Date: string;
    Invoice_No: string;
    Invoice_date: string;
    Payment_Release_Date: string;
    Payment_Value_in_INR: any;
    Balance_Amount: any;
    Upload_Quotation: FileList | null;
    Upload_PO_Reference: FileList | null;
    Upload_Invoice: FileList | null;
    CreatedBy: string;
    PlantId: string;
    PO_Remarks: any;
    Invoice_Remarks: any;
    Payment_Term_In_Days: any;
   // Invoice_No:any;
  };
  Quotation_Date = new FormControl(new Date("yyyy-mm-dd"));
  PO_Date = new FormControl(new Date("yyyy-mm-dd"));
  Invoice_date = new FormControl(new Date("yyyy-mm-dd"));
  Payment_Release_Date = new FormControl(new Date("yyyy-mm-dd"));
  fileToUpload: any;
  POID = 0;
  searchTerm: any;
  status: any = "";
  shared: any;
  jsonParam: any = [];
  formgroup: any;
  SharedService: any;
  message: string;
  isActiveDiv: boolean;
  OperatingMasterLists: any;
  fileName: string;
  License_Doc: any;
  OperatingMasterList: void;
  DelDataByTables: any;
  POMasterList: any;
  POMasterLists: any;
  PlantId: string;
  Upload_Quotation: any;
  Upload_PO_Reference: any;
  Upload_Invoice: any;
  Roleid: string;
  GetBISProduct: any;
  BISProduct: any;
  BISModel=[];
  BISSeries: any;
  BISCategory: any;
  BISYear: any;
  BISMfg: any;
  GetMfgList: any;
  GetBISProductListByParam: any;
  stringJson: string;
  stringObject: any;
  selected: any;
  dropdownListsub: string;
  mdl_for_BIS_Array: any = [];
  myString: any;
  edit_Model_str: any =[];
  temp_ModelForBIS_str: any =[];
  //pusheditems: { [mod_for_Bis: string]: any; } = {}; 
  public Modelform: {
    model_For_BIS:any;
  }
  public agents : Agent[];
  
  //dropdownList: object;
  constructor(
    private authService: AuthService,
    private service: SharedService,
    private notifyService: NotificationService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {
    this.uploadStatus = new EventEmitter<ProgressStatus>();
    let agents :Agent[]= []; 
    this.agents = agents; 
   this.Modelform = {
    model_For_BIS: ""
   };

    this.form = {
      POID: "",
      MfgPlantID: 1,
      MfgPlant1ID: 2,
      PO_Type: "",
      Category: "",
      Product: "",
      Lead_Model: "",
      Model_for_BIS: "",
      Supplier_Name: "",
      Quotation_Reference_No: "",
      Quotation_Date: "",
      PO_Reference_No: "",
      PO_Value_in_INR: "",
      PO_Date: "",
      Invoice_No: "",
      Invoice_date: "",
      Payment_Release_Date: "",
      Payment_Value_in_INR: "",
      Balance_Amount: "",
      Upload_Quotation: null,
      Upload_PO_Reference: null,
      Upload_Invoice: null,
      CreatedBy: "",
      PlantId: "",
     
      PO_Remarks: "",
      Invoice_Remarks:  "",
      Payment_Term_In_Days:  0,
     // Invoice_No:""
    };
  }

  public subsVar: Subscription | undefined;

  ngOnInit(): void {

  
    this.GetKeyFiltersBy_Product();
    this.GetMfgPlantList();
    
    this.EnableAppHeaderMenuList();
    this.PlantId = localStorage.getItem("PlantId");
    this.CategoryProductFilter();
    let type = this.activatedRoute.snapshot.params["type"];
    this.Roleid = localStorage.getItem("RoleID");
    this.GetPOMasterLists();
    this.form.POID = 0;

    this.service.POMasterList(this.jsonParam).subscribe(response => {
      this.POMasterLists = response;
    });
  }

  CategoryProductFilter() {

    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };

    this.service.ProductPOFilters(this.jsonParam).subscribe(response => {

      this.GetBISProduct = response;

      this.BISProduct = this.GetBISProduct.table;
     
      this.BISSeries = this.GetBISProduct.table2;

      this.BISCategory = this.GetBISProduct.table4;
      this.BISYear = this.GetBISProduct.table6;
      this.BISMfg = this.GetBISProduct.table5;
      console.log(this.GetBISProduct);
    });
  }
  GetMfgPlantList() {
   
    this.service.GetMfgPlant().subscribe(
      response => {
        this.GetMfgList = response.table;
      },
      error => {
        this.authService.logout();
      }
    );
  }
  GetKeyFiltersBy_Product() {
  
    this.jsonParam = {
      category: this.form.Category,
      product: this.form.Product,
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };
    
    this.service.GetBISKeyFiltersBy_ModelforbisPO(this.jsonParam).subscribe(
      response => {
      
        this.GetBISProductListByParam = response;
        this.BISModel = this.GetBISProductListByParam.table;
        this.dropdownList =this.BISModel;
        this.selectedItems = this.BISModel;
       // this.form.Model_for_BIS = this.BISModel;
        this.dropdownSettings= {
      
          singleSelection: false,
          idField:'model_For_BIS',
          textField: 'model_For_BIS',
          selectAllText: 'Select All',
          unSelectAllText: 'UnSelect All',
          itemsShowLimit: 3,
          allowSearchFilter: true,
          clearSearchFilter: true
        };
        
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  onItemDeSelect(item: any) {
   
    let index: number = this.mdl_for_BIS_Array.indexOf(item.model_For_BIS);
    if(index > -1)
    {

     
      this.mdl_for_BIS_Array.splice(0);

     // this.mdl_for_BIS_Array.splice(index, 1);
      
      this.form.Model_for_BIS.forEach(x => {
        console.log(x.model_For_BIS);
        this.mdl_for_BIS_Array.push(x.model_For_BIS);
      });

      this.myString = this.mdl_for_BIS_Array.toString();
      console.log(this.myString);
      this.edit_Model_str =this.myString.split(',');

      let arraylist = new Agent();
      this.agents.splice(0);
      let pusheditems = {};
      this.edit_Model_str.forEach(obj => {
  
        pusheditems['mod_for_biss'] = obj;
        this.agents.push(<Agent>{ model_For_BIS:pusheditems['mod_for_biss']});
        this.Modelform.model_For_BIS = this.agents;
        console.log(this.form.Model_for_BIS);
        }); 

    }
  }
  onItemSelect(item: any) {
    // const mdl_for_BIS_Array = this.form.get('mdl_for_BIS_Array') as FormArray
    debugger
   // this.mdl_for_BIS_Array.push(this.form.Model_for_BIS);


      

      // angular.forEach(this.form.Model_for_BIS, function(value, key) {
      //   console.log('key:', key);
      //   console.log('value:', value);
      // });
      this.mdl_for_BIS_Array.splice(0);
      let index: number = this.mdl_for_BIS_Array.indexOf(item.model_For_BIS);
      if(index == -1)
      {
        var num = this.form.Model_for_BIS.forEach(x => {
          console.log(x.model_For_BIS);
          this.mdl_for_BIS_Array.push(x.model_For_BIS);
        });

      //  this.mdl_for_BIS_Array.push(item.model_For_BIS);
        this.myString = this.mdl_for_BIS_Array.toString();
        console.log(this.myString);
        
        this.edit_Model_str =this.myString.split(',');
        let arraylist = new Agent();
        this.agents.splice(0);
        let pusheditems = {};
        this.edit_Model_str.forEach(obj => {    
        pusheditems['mod_for_biss'] = obj;
        this.agents.push(<Agent>{ model_For_BIS:pusheditems['mod_for_biss']});
        this.Modelform.model_For_BIS = this.agents;
        //  this.form.Model_for_BIS = this.agents;
        console.log(this.form.Model_for_BIS);

          });

      }
      else{
        this.mdl_for_BIS_Array.splice(index, 1);
      }
      

      // let dirtyValues = {};
      //    Object.keys(item.model_For_BIS)
      //        .forEach(key => {
      //            let currentControl = item.model_For_BIS[key];
 
      //            if (currentControl.dirty) {
      //                if (currentControl.controls)
      //                    dirtyValues[key] = this.onItemSelect(currentControl);
      //                else
      //                    dirtyValues[key] = currentControl.value;
      //            }
      //        });

   };

   onSelectAll(items: any) {

     console.log(items);
     this.mdl_for_BIS_Array.splice(0);

       var num = items.forEach(x => {
         console.log(x.model_For_BIS);
         this.mdl_for_BIS_Array.push(x.model_For_BIS);
       });

       this.myString = this.mdl_for_BIS_Array.toString();
       console.log(this.myString);
  }

  GetKeyFiltersBy_category() {
     
    this.form.Product = "";

    this.jsonParam = {
      Category: this.form.Category,
      plantId: localStorage.getItem("PlantId"),
      product: "",
      mfgPlantID: 1
    };
     
    this.service.GetBISKeyFiltersBy_ParamPO(this.jsonParam).subscribe(
      response => {
         
        this.GetBISProductListByParam = response;
        this.BISProduct = this.GetBISProductListByParam.table;
        
        this.BISSeries = this.GetBISProductListByParam.table4;
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetPOMasterLists() {
    this.jsonParam = {
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };
    this.service.POMasterList(this.jsonParam).subscribe(response => {
      this.POMasterLists = response;
    });
  }

  refresh(): void {
    window.location.reload();
  }

  EditPOMaster(element: any) {
      
    this.CategoryProductFilter();
    this.dropdownList.splice(0);
    this.form.Model_for_BIS ={};
 
    this.jsonParam = {
      Category: element.category,
      plantId: localStorage.getItem("PlantId"),
      product: "",
      mfgPlantID: 1
    };
     
    this.service.GetBISKeyFiltersBy_ParamPO(this.jsonParam).subscribe(
      response => {
        this.GetBISProductListByParam = response;
        this.BISProduct = this.GetBISProductListByParam.table;
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );


    this.jsonParam = {
      category: element.category,
      product: element.product,
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };
    
    this.service.GetBISKeyFiltersBy_ModelforbisPO(this.jsonParam).subscribe(
      response => {
        this.GetBISProductListByParam = response;
        this.BISModel = this.GetBISProductListByParam.table;      
        this.dropdownList =this.BISModel;

        this.edit_Model_str = element.model_for_BIS.split(',');
        let arraylist = new Agent();
        this.agents.splice(0);
        let pusheditems = {};
        this.edit_Model_str.forEach(obj => {
        pusheditems['mod_for_biss'] = obj;
        this.agents.push(<Agent>{ model_For_BIS:pusheditems['mod_for_biss']});
        console.log(this.form.Model_for_BIS);
        });

        this.dropdownSettings= { 
          singleSelection: false,
          idField:'model_For_BIS',
          textField: 'model_For_BIS',
          selectAllText: 'Select All',
          unSelectAllText: 'UnSelect All',
          itemsShowLimit: 3,
          allowSearchFilter: true,
          clearSearchFilter: true
        };

        this.selectedItems =this.agents;
        this.form.Model_for_BIS = this.agents;
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
    
    this.edit_Model_str =element.model_for_BIS.split(',');
 
    this.edit_Model_str.forEach(obj => {  
    this.mdl_for_BIS_Array.push(obj);  
    });

debugger
    this.isActiveDiv = true;
    this.form.POID = element.poid;
    this.form.Category = element.category;
    this.form.Product = element.product;
    //this.form.Lead_Model = element.lead_Model;
    this.form.PO_Type = element.pO_Type;
  //  this.form.Model_for_BIS = element.model_for_BIS;
    this.form.Supplier_Name = element.supplier_Name;
    this.form.Quotation_Reference_No = element.quotation_Reference_No;
    this.form.Quotation_Date = element.quotation_Date;
    this.form.PO_Reference_No = element.pO_Reference_No;
    this.form.PO_Value_in_INR = element.pO_Value_in_INR;
    this.form.PO_Date = element.pO_Date;
    this.form.Invoice_No = element.invoice_No;
    this.form.Invoice_date = element.invoice_date;
    this.form.Payment_Release_Date = element.payment_Release_Date;
    this.form.Payment_Value_in_INR = element.payment_Value_in_INR;
    this.form.Payment_Term_In_Days=element.payment_Term_In_Days;
    this.form.Balance_Amount = element.balance_Amount;
    this.form.CreatedBy = element.createdBy;
    this.form.PlantId = element.plantId;
  }

  PostDelDataByTables(param: any) {
    this.jsonParam = {
      delId: param,
      str: "POReference",
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.PostDelDataByTable(this.jsonParam).subscribe(response => {
      this.DelDataByTables = response;
      console.log(this.DelDataByTables);
      if ((response.success = "DeleteSuccess")) {
        Swal.fire("Great!", "Delete Successfully!", "success");
        this.GetPOMasterLists();
      }
    });
  }

  public POApplication() {
debugger;
    var POID = this.form.POID;
    var Category = this.form.Category;
    var Product = this.form.Product;
    // var Lead_Model = this.form.Lead_Model;
    var PO_Type = this.form.PO_Type;
    var Model_for_BIS = this.myString;
    var Supplier_Name = this.form.Supplier_Name;
    var Quotation_Reference_No = this.form.Quotation_Reference_No;

    var Quotation_Date = this.form.Quotation_Date != ""
    ? moment(this.form.Quotation_Date).format("YYYY-MM-DD")
    : "";
    
    var PO_Value_in_INR = this.form.PO_Value_in_INR;
    var PO_Reference_No = this.form.PO_Reference_No;
    var PO_Date =
      this.form.PO_Date != ""
        ? moment(this.form.PO_Date).format("YYYY-MM-DD")
        : "";
    var Invoice_No = this.form.Invoice_No;
    var Invoice_date =
    this.form.Invoice_date != ""
      ? moment(this.form.Invoice_date).format("YYYY-MM-DD")
      : "";
    var Payment_Release_Date =
      this.form.Payment_Release_Date != ""
        ? moment(this.form.Payment_Release_Date).format("YYYY-MM-DD")
        : "";
        var Payment_Term_In_Days = this.form.Payment_Term_In_Days;
        var PO_Remarks = this.form.PO_Remarks;
        var Invoice_Remarks = this.form.Invoice_Remarks;
        var Invoice_No=this.form.Invoice_No;
    var Payment_Value_in_INR = this.form.Payment_Value_in_INR;
    var Balance_Amount =
      +this.form.PO_Value_in_INR - +this.form.Payment_Value_in_INR;
    var Upload_Quotation =
      this.form.Upload_Quotation && this.form.Upload_Quotation.length
        ? this.form.Upload_Quotation[0]
        : null;
    var Upload_PO_Reference =
      this.form.Upload_PO_Reference && this.form.Upload_PO_Reference.length
        ? this.form.Upload_PO_Reference[0]
        : null;
    var Upload_Invoice =
      this.form.Upload_Invoice && this.form.Upload_Invoice.length
        ? this.form.Upload_Invoice[0]
        : null;
    var CreatedBy = localStorage.getItem("name");
    var PlantId = localStorage.getItem("PlantId");
    var  MfgPlantID = 1;
   

    this.service.POApplication({
        POID: POID,
        Category: Category,
        Product: Product,
        Model_for_BIS: Model_for_BIS,
        // Lead_Model: Lead_Model,
        PO_Type: PO_Type,
        Supplier_Name: Supplier_Name,
        Quotation_Reference_No: Quotation_Reference_No,
        Quotation_Date: Quotation_Date,
        PO_Reference_No: PO_Reference_No,
        PO_Value_in_INR: PO_Value_in_INR,
        PO_Date: PO_Date,
        Invoice_No: Invoice_No,
        Invoice_date: Invoice_date,
        Payment_Release_Date: Payment_Release_Date,
        Payment_Value_in_INR: Payment_Value_in_INR,
        Balance_Amount: Balance_Amount,
        CreatedBy: CreatedBy,
        PlantId: PlantId,
        Upload_Quotation: Upload_Quotation,
        Upload_PO_Reference: Upload_PO_Reference,
        Upload_Invoice: Upload_Invoice,
        Payment_Term_In_Days :Payment_Term_In_Days,
        PO_Remarks :PO_Remarks,
       Invoice_Remarks:Invoice_Remarks,
    //   Invoice_No:Invoice_No,
       MfgPlantID:MfgPlantID
      })
      .subscribe(
        data => {
          if (data) {
            console.log(data);
             ;
            switch (data.type) {
              case HttpEventType.UploadProgress:
                this.uploadStatus.emit({
                  status: ProgressStatusEnum.IN_PROGRESS,
                  percentage: Math.round((data.loaded / data.total) * 100)
                });
                break;
              case HttpEventType.Response:
                this.POMasterLists = data.body;

                this.uploadStatus.emit({ status: ProgressStatusEnum.COMPLETE });

                Swal.fire("Great!", "Data Created Successfully!", "success");
                break;
            }
            Swal.fire("Great!", "Data Created Successfully!", "success");

            this.GetPOMasterLists();

            this.form.Category = "";
            this.form.Product = "";
            this.form.PO_Type = "";
            this.form.Model_for_BIS = "";
            this.form.Supplier_Name = "";
            this.form.Quotation_Reference_No = "";
            this.form.Quotation_Date = "";
            this.form.PO_Reference_No = "";
            this.form.PO_Date = "";
            this.form.PO_Value_in_INR = "";
            this.form.Invoice_No = "";
            this.form.Invoice_date = "";
            this.form.Payment_Release_Date = "";
            this.form.Payment_Value_in_INR = "";
            this.form.Balance_Amount = "";
            this.form.Upload_Quotation= null;
            this.form.Upload_PO_Reference=null;
            this.form.Upload_Invoice=null;
            this.form.Payment_Term_In_Days ="";
            this.form.PO_Remarks ="";
            this.form.Invoice_Remarks="";
            this.form.Invoice_No="";
            this.inputvar1.nativeElement.value = "";

            this.inputvar2.nativeElement.value = "";

            this.inputvar3.nativeElement.value = "";
          }
        },
        error => {
          this.inputFile.nativeElement.value = "";
          this.uploadStatus.emit({ status: ProgressStatusEnum.ERROR });
        }
      );
  }

  public upload(event) {
    if (event.target.files && event.target.files.length > 0) {
      this.fileToUpload = event.target.files[0];
      this.uploadStatus.emit({ status: ProgressStatusEnum.START });
    }
  }
 
  uploadfile() {
     ;
    this.service.uploadFile(this.fileToUpload).subscribe(
      data => {
        if (data) {
          switch (data.type) {
            case HttpEventType.UploadProgress:
              this.uploadStatus.emit({
                status: ProgressStatusEnum.IN_PROGRESS,
                percentage: Math.round((data.loaded / data.total) * 100)
              });
              break;
            case HttpEventType.Response:
              this.inputFile.nativeElement.value = "";
              this.uploadStatus.emit({ status: ProgressStatusEnum.COMPLETE });
              break;
          }
        }
      },
      error => {
        this.inputFile.nativeElement.value = "";
        this.uploadStatus.emit({ status: ProgressStatusEnum.ERROR });
      }
    );
  }

  EnableAppHeaderMenuList() {
    this.service.EnableHeaderMenuList();
  }
  home() {
    this.router.navigate(["/dashboard"]);
  }

  ngAfterViewInit() {}
  Download(fileName: any, Str: any): void {
     ;
    this.jsonParam = {
      fileName: fileName,
      Str: Str
    };

    this.service
      .DownloadFile(this.jsonParam)
      .subscribe(blob => saveAs(blob, fileName));
  }
  downloadFile() {
    this.Upload_Quotation.download().subscribe(
      res => {
        const blob = new Blob([res.blob()], {
          type: "application/vnd.ms.excel"
        });
        const file = new File([blob], this.fileName + ".xlsx", {
          type: "application/vnd.ms.excel"
        });
      },
      res => {}
    );
    this.Upload_PO_Reference.download().subscribe(
      res => {
        const blob = new Blob([res.blob()], {
          type: "application/vnd.ms.excel"
        });
        const file = new File([blob], this.fileName + ".xlsx", {
          type: "application/vnd.ms.excel"
        });
      },
      res => {}
    );
    this.Upload_Invoice.download().subscribe(
      res => {
        const blob = new Blob([res.blob()], {
          type: "application/vnd.ms.excel"
        });
        const file = new File([blob], this.fileName + ".xlsx", {
          type: "application/vnd.ms.excel"
        });
      },
      res => {}
    );
  }
  resetForm() {

    this.GetMfgPlantList();
   
    
    this.form = {
      POID: "",
      MfgPlantID: "1",
      MfgPlant1ID: "2",
      PO_Type: "",
      Category: "",
      Product: "",
      Lead_Model: "",
      Model_for_BIS: "",
      Supplier_Name: "",
      Quotation_Reference_No: "",
      Quotation_Date: "",
      PO_Reference_No: "",
      PO_Value_in_INR: "",
      PO_Date: "",
      Invoice_No: "",
      Invoice_date: "",
      Payment_Release_Date: "",
      Payment_Value_in_INR: "",
      Balance_Amount: "",
      Upload_Quotation: null,
      Upload_PO_Reference: null,
      Upload_Invoice: null,
      CreatedBy: "",
      PlantId: "",
     
      PO_Remarks: "",
      Invoice_Remarks:  "",
      Payment_Term_In_Days:  "",
    };

  }
  handleClear() {
    this.form.Category = "";
    this.form.Product = "";
    this.form.Lead_Model = "";
    this.form.Model_for_BIS = "";
    this.form.Supplier_Name = "";
    this.form.Quotation_Reference_No = "";
    this.form.Quotation_Date = "";
    this.form.PO_Reference_No = "";
    this.form.PO_Date = "";
    this.form.PO_Value_in_INR = "";
    this.form.Invoice_No = "";
    this.form.Invoice_date = "";
    this.form.Payment_Release_Date = "";
    this.form.Payment_Value_in_INR = "";
    this.form.Balance_Amount = "";
  }
}
export class Agent{
  model_For_BIS: string;
}