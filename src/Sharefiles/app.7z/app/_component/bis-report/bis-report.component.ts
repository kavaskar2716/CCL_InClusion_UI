import {
  Component,
  OnInit,
  HostListener,
  Inject,
  ViewChild,
  ElementRef
} from "@angular/core";
import { AuthService } from "src/app/_services/auth.service";
import { Observable, Subscription, of, throwError } from "rxjs";
import { NotificationService } from "src/app/notification.service";
import { SharedService } from "src/app/shared.service";
import { Router } from "@angular/router";
import * as _ from "lodash";
import { ActivatedRoute } from "@angular/router";
import * as XLSX from "xlsx";
declare var jQuery: any;
declare var scrollTop: any;
@Component({
  selector: "app-bis-report",
  templateUrl: "./bis-report.component.html",
  styleUrls: ["./bis-report.component.css"]
})
export class BisReportComponent implements OnInit {
  @ViewChild("TABLE", { static: false }) TABLE: ElementRef;
  isTableExpanded = false;
  searchTerm: any;
  searchText;
  public filterTerm!: any;
  ProductItemList: any = [];
  param: any;
  jsonParam: any = [];
  ProductType: string = "";
  ProductItemLists: any = [];
  ResProductFilterList: any = [];
  value1: any;
  target: HTMLButtonElement | undefined;
  ProdComplainenceLists: any = [];
  ProdMachineTypeLists: any = [];
  ProdMarketingSeriesLists: any = [];
  compid: any = "";
  machineid: any = "";
  marketingid: any = "";
  status: any = "";
  machineDisabled: boolean = false;
  msDisabled: boolean = false;
  compDisabled: boolean = false;
  stsDisabled: boolean = false;
  BISMasterLists: any;
  raw: boolean;
  PlantId: string;
  form: {
    category: string;
    product: string;
    modelForBis: string;
    series_Model: string;
    status: string;
    plantId: string;
    fy: string;
    mfgName: any;
  };
  GetBISProduct: any;
  BISProduct: any;
  BISModel: any;
  BISSeries: any;
  BISStatus: any;
  BISCategory: any;
  BISMfg: any;
  BISYear: any;
  seriesModel: string;
  GetBISProductByFY: any;
  GetBISProductListByParam: any;

  constructor(
    private authService: AuthService,
    private service: SharedService,
    private notifyService: NotificationService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {
    this.form = {
      category: "",
      product: "",
      modelForBis: "",
      series_Model: "",
      status: "",
      plantId: "",
      fy: "",
      mfgName: 1
    };
  }

  public subsVar: Subscription | undefined;

  ngOnInit(): void {
    this.BISProgramMasterLists();
    this.ProductCommonFilters();
    this.EnableAppHeaderMenuList();
    this.PlantId = localStorage.getItem("PlantId");
    let type = this.activatedRoute.snapshot.params["type"];
    this.activatedRoute.paramMap.subscribe(params => {
      type = params.get("type");
      console.log(type);
      this.ProductType = type;
      this.ProductItemList = null;
      console.log(this.filterTerm);
    });

    //this.statusfilter("ALL");
    this.ProductItemList.data = this.ProductItemList;
    this.form.mfgName = "1";
  }

  BISProgramMasterLists() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };

    this.service.BISProgramMasterList(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response;

        console.log(this.ProductItemList);
      },
      error => {
        this.authService.logout();
      }
    );
  }
  ProductCommonFilters() {

    debugger;

    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };

    this.service.ProductCommonFilters(this.jsonParam).subscribe(response => {

      debugger;

      this.GetBISProduct = response;



      this.BISProduct = this.GetBISProduct.table;

      this.BISModel = this.GetBISProduct.table1;

      this.BISSeries = this.GetBISProduct.table2;

      this.BISStatus = this.GetBISProduct.table3;

      this.BISCategory = this.GetBISProduct.table4;

      this.BISMfg = this.GetBISProduct.table5;

      this.BISYear = this.GetBISProduct.table6;

      console.log(this.GetBISProduct);

    });

  }

  GetProdListByFY(param: any) {
    debugger;
    this.form.product = "";
    this.form.modelForBis = "";
    this.form.series_Model = "";
    this.jsonParam = {
      fy: param,
      Category: "NULL",
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 0
    };
    debugger;
    this.service.GetBISProdListByFY(this.jsonParam).subscribe(
      response => {
        this.GetBISProductByFY = response;
        this.BISProduct = this.GetBISProductByFY.table1;
        this.BISModel = this.GetBISProductByFY.table2;
        this.BISSeries = this.GetBISProductByFY.table3;
        console.log(this.GetBISProductByFY);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetKeyFiltersBy_category() {
    debugger;
    this.form.product = "";
    this.form.modelForBis = "";
    this.form.series_Model = "";
    this.jsonParam = {
      category: this.form.category,
      product: "",
      modelForBis: "",
      seriesModel: "",
      status: "",
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1,
      fy: this.form.fy
    };
    debugger;
    this.service.GetBISKeyFiltersBy_Param(this.jsonParam).subscribe(
      response => {
        debugger;
        this.GetBISProductListByParam = response;
        this.BISProduct = this.GetBISProductListByParam.table2;
        this.BISModel = this.GetBISProductListByParam.table3;
        this.BISSeries = this.GetBISProductListByParam.table4;
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetKeyFiltersBy_Product() {
    debugger;
    this.form.modelForBis = "";
    this.form.series_Model = "";
    this.jsonParam = {
      category: this.form.category,
      product: this.form.product,
      modelForBis: "",
      seriesModel: "",
      status: "",
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1,
      fy: this.form.fy
    };
    debugger;
    this.service.GetBISKeyFiltersBy_Param(this.jsonParam).subscribe(
      response => {
        debugger;
        this.GetBISProductListByParam = response;
        this.BISModel = this.GetBISProductListByParam.table3;
        this.BISSeries = this.GetBISProductListByParam.table4;
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetKeyFiltersBy_Model() {
    debugger;

    this.jsonParam = {
      category: this.form.category,
      product: this.form.product,
      modelForBis: this.form.modelForBis,
      seriesModel: "",
      status: "",
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1,
      fy: this.form.fy
    };
    debugger;
    this.service.GetBISKeyFiltersBy_Param(this.jsonParam).subscribe(
      response => {
        debugger;
        this.GetBISProductListByParam = response;
        this.BISSeries = this.GetBISProductListByParam.table4;
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  onfilter() {
    this.jsonParam = {
      category: this.form.category,
      product: this.form.product,
      modelForBis: this.form.modelForBis,
      seriesModel: this.form.series_Model,
      status: this.form.status,
      fy: this.form.fy,
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };
    debugger;
    this.service.ProductByFilters(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response.table;
        this.ProductItemLists = this.ProductItemList;
        console.log(this.ProductItemList);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  statusfilter(_status: any) {
    this.machineDisabled = true;
    this.compDisabled = true;
    this.msDisabled = true;

    this.jsonParam = {
      SearchStr: _status,
      Str: "STATUS",
      category: this.ProductType
    };

    this.service.ProductByFilters(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response;
        this.ProductItemLists = this.ProductItemList;
        this.ProductItemList.data = this.ProductItemList;
        console.log(this.ProductItemList);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  EnableAppHeaderMenuList() {
    this.service.EnableHeaderMenuList();
  }
  home() {
    this.router.navigate(["/dashboard"]);
  }

  ClearFilter() {
    this.machineDisabled = false;
    this.compDisabled = false;
    this.msDisabled = false;
    this.stsDisabled = false;

    this.form.fy = "";
    this.form.category = "";
    this.form.modelForBis = "";
    this.form.series_Model = "";
    this.form.product = "";
    this.form.status = "";

    this.ProductItemList = null;
  }

  ProductFilters(param: string) {
    this.jsonParam = {
      ProductId: 0,
      ProductName: param
    };

    this.service.ProductFilters(this.jsonParam).subscribe(
      response => {
        this.ResProductFilterList = response;
        this.ProdComplainenceLists = this.ResProductFilterList.resProdComplainenceLists;
        this.ProdMachineTypeLists = this.ResProductFilterList.resProdMachineTypeLists;
        this.ProdMarketingSeriesLists = this.ResProductFilterList.resProdMarketingSeriesLists;

        console.log(this.ResProductFilterList);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  search(event: Event): void {
    this.value1 = (event.target as HTMLInputElement).value;
    this.ProductItemList = this.ProductItemLists.filter((val: any) =>
      val.name.toLowerCase().includes(this.value1)
    );
  }

  title = "Excel";
  ExportTOExcel() {
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(
      this.TABLE.nativeElement,
      { raw: true }
    );
    const wb: XLSX.WorkBook = XLSX.utils.book_new();

    ws["A1"].s = {
      fill: {
        patternType: "none", // none / solid
        fgColor: { rgb: "FF000000" },
        bgColor: { rgb: "FFFFFFFF" }
      },
      font: {
        name: "Times New Roman",
        sz: 16,
        color: { rgb: "#FF000000" },
        bold: true,
        italic: false,
        underline: false
      },
      border: {
        top: { style: "thin", color: { auto: 1 } },
        right: { style: "thin", color: { auto: 1 } },
        bottom: { style: "thin", color: { auto: 1 } },
        left: { style: "thin", color: { auto: 1 } }
      }
    };
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
    XLSX.writeFile(wb, "Excelreport.xlsx");
  }

  team: any = this.ProductItemList;
}
