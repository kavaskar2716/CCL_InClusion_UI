import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingInclusionComponent } from './pending-inclusion.component';

describe('PendingInclusionComponent', () => {
  let component: PendingInclusionComponent;
  let fixture: ComponentFixture<PendingInclusionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PendingInclusionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingInclusionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
