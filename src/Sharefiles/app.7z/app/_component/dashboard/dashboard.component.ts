import { DOCUMENT } from "@angular/common";
import {
  Component,
  OnDestroy,
  OnInit,
  Injectable,
  HostListener,
  Inject,
  NgZone,
  PLATFORM_ID
} from "@angular/core";
import { AuthService } from "../../_services/auth.service";
import { Observable, Subscription, of, throwError } from "rxjs";
import { NotificationService } from "src/app/notification.service";
import { SharedService } from "src/app/shared.service";
import { isPlatformBrowser } from "@angular/common";
import { SwiperOptions, Swiper, Navigation, Pagination } from "swiper";
import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import { NgxSpinnerService } from "ngx-spinner";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { NgbCarouselConfig } from "@ng-bootstrap/ng-bootstrap";
import { ToastrService } from "ngx-toastr";
import Swal from "sweetalert2";
declare var jQuery: any;
const swiper = new Swiper(".swiper-container", {
  pagination: {
    el: ".swiper-pagination",
    type: "bullets"
  }
});
@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"],
  providers: [NgbCarouselConfig] // add NgbCarouselConfig to the
})
export class DashboardComponent implements OnInit {
  private root: am5.Root;
  model: any = {};
  elem: any;
  param: any;
  mySwiper: Swiper;
  timeout;
  routerChanged = true;
  //declare variable
  isFullScreen: boolean | undefined;
  @HostListener("document:fullscreenchange", ["$event"])
  @HostListener("document:webkitfullscreenchange", ["$event"])
  @HostListener("document:mozfullscreenchange", ["$event"])
  @HostListener("document:MSFullscreenChange", ["$event"])
  searchText: any;
  searchText1: any;
  searchText2: any;
  DashboardList: any = [];
  ProductList: any = [];
  DashboardBoxList: any = [];
  DashboardTilesList: any = [];
  Swiper: any;
  BISGrantedList: any;
  BISLabTestReportList: any;
  BISPendingList: any;
  GetBISChart: any;
  Chart1: object;
  Chart2: object;
  Chart3: object;
  jsonParam: any;
  Notebook_Box: any;
  WS_Box: any;
  MiniPC_Box: any;
  showNavigationArrows = false;
  showNavigationIndicators = false;
  images = [
    "assets/Image/Ban1.png",
    "assets/Image/Ban2.png",
    "assets/Image/Ban3.png",
    "assets/Image/Ban4.png"
  ];
  OperatingList: any;
  GrantedReportByDaysList: any;
  PendingByDaysList: any;
  GetGrantdata: any;

  Wip: any;
  Plan: any;
  Grant: any;
  countdata: any;
  Granted: any;
  GrantedFull: any;
  WipFull: any;
  PlanFull: any;
  PlantId: string;
  activatedRoute: any;
  category: string;
  form: {
    category: string;
    product: string;
    modelForBis: string;
    seriesModel: string;
    status: string;
    plantId: string;
    fy: string;
    mfgPlantID: string;
  };

  GrantedFulls: any;
  GetBISProduct: any;
  BISProduct: any;
  BISModel: any;
  BISSeries: any;

  BISYear: any;
  BISProduct2: any;
  BISStatus: any;
  RoleId: string;
  msg: string;
  paycount: any;
  BISQueryCount: any;
  payBycount: any;
  BISQueryBycount: any;

  constructor(
    private authService: AuthService,
    private service: SharedService,
    private notifyService: NotificationService,
    private spinner: NgxSpinnerService,
    private toastrService: ToastrService,
    @Inject(DOCUMENT) private document: any,
    @Inject(PLATFORM_ID) private platformId,
    private zone: NgZone
  ) {
    this.form = {
      category: "",
      product: "",
      modelForBis: "",
      seriesModel: "",
      status: "",
      plantId: "",
      fy: "",
      mfgPlantID: ""
    };
  }
  browserOnly(f: () => void) {
    if (isPlatformBrowser(this.platformId)) {
      this.zone.runOutsideAngular(() => {
        f();
      });
    }
  }
  public showInfo(): void {
    Swal.fire("Access Denied !!!");
  }
  public showError(): void {
    Swal.fire("No Data");
  }
  ManageDataByPlant() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.DataByPlant(this.jsonParam).subscribe(response => {
      this.Granted = response.table;

      console.log(this.Granted);
    });
  }

  ManageListStatus(param: any) {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1,
      category: param,
      status: "Granted"
    };
    this.service.ListStatusData(this.jsonParam).subscribe(response => {
      this.GrantedFull = response.table;

      console.log(this.GrantedFull);
    });
  }
  ManageListStatusWIP(param: any) {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1,
      category: param,
      status: "WIP"
    };
    this.service.ListStatusData(this.jsonParam).subscribe(response => {
      this.WipFull = response.table;

      console.log(this.WipFull);
    });
  }
  ManageListStatusPlan(param: any) {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1,
      category: param,
      status: "Plan"
    };
    this.service.ListStatusData(this.jsonParam).subscribe(response => {
      this.PlanFull = response.table;

      console.log(this.PlanFull);
    });
  }

  ManageGetBISCharts() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.ManageGetBISChart(this.jsonParam).subscribe(response => {
      this.GetBISChart = response;
      this.Chart1 = this.GetBISChart.table;
      this.Chart2 = this.GetBISChart.table1;
      this.Chart3 = this.GetBISChart.table2;
      console.log(this.GetBISChart);
      console.log(this.Chart1);
      console.log(this.Chart2);
      console.log(this.Chart3);
      this.RenderPlanVsActualChart(this.Chart1);
      this.RenderLastThreeYearChart(this.Chart2);
      this.RenderFYGrantedChart(this.Chart3);
    });
  }
  ngAfterViewInit() {
    this.ManageGetBISCharts();

    this.mySwiper = new Swiper(".swiper-container", {
      autoplay: {
        delay: 3000,
        disableOnInteraction: false
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true
      },

      // Navigation arrows
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev"
      },
      speed: 3000,

      loop: false,

      effect: "flip",
      grabCursor: true,
      flipEffect: {
        slideShadows: true,
        limitRotation: true
      },

      on: {
        init() {
          this.el.addEventListener("mouseenter", () => {
            this.autoplay.stop();
          });
          this.el.addEventListener("mouseleave", () => {
            this.autoplay.start();
          });
        }
      }
    });
  }

  ngOnDestroy() {
    this.browserOnly(() => {
      if (this.root) {
        this.root.dispose();
      }
    });
  }

  GetBISGrantedReportByDays(param: any) {
    this.jsonParam = {
      agingDays: param,
      PlantId: localStorage.getItem("PlantId")
    };
    this.service
      .GetBISGrantedReportByDays(this.jsonParam)
      .subscribe(response => {
        this.GrantedReportByDaysList = response;

        console.log(this.GrantedReportByDaysList);
      });
  }
  GetBISPendingInclusionByDays(param: any) {
    this.jsonParam = {
      agingDays: param,
      PlantId: localStorage.getItem("PlantId")
    };
    this.service
      .GetBISPendingInclusionByDays(this.jsonParam)
      .subscribe(response => {
        this.PendingByDaysList = response;

        console.log(this.PendingByDaysList);
      });
  }

  GetOperativeLicenseList() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.OperatingMasterList(this.jsonParam).subscribe(
      response => {
        this.OperatingList = response;
      },
      error => {
        this.authService.logout();
      }
    );
  }
  RenderPlanVsActualChart1(Chart1) {
    let root = am5.Root.new("chartdiv");

    root._logo.dispose();

    root.setThemes([am5themes_Animated.new(root)]);

    let chart = root.container.children.push(
      am5xy.XYChart.new(root, {
        panX: false,
        panY: false,
        wheelX: "panX",
        wheelY: "zoomX",
        layout: root.verticalLayout
      })
    );
    chart
      .get("colors")
      .set("colors", [am5.color(0x03a9f4), am5.color(0x70ad47)]);

    let legend = chart.children.push(
      am5.Legend.new(root, {
        centerX: am5.p50,
        x: am5.p50
      })
    );
    legend.labels.template.setAll({
      fontSize: 14
    });

    let data = Chart1;

    let xAxis = chart.xAxes.push(
      am5xy.CategoryAxis.new(root, {
        categoryField: "category",

        renderer: am5xy.AxisRendererX.new(root, {
          cellStartLocation: 0.1,
          cellEndLocation: 0.9
        }),
        tooltip: am5.Tooltip.new(root, {})
      })
    );

    xAxis.data.setAll(data);

    let yAxis = chart.yAxes.push(
      am5xy.ValueAxis.new(root, {
        renderer: am5xy.AxisRendererY.new(root, {}),
        maxDeviation: 0.4
      })
    );
    let yRenderer = yAxis.get("renderer");
    yRenderer.labels.template.setAll({
      textAlign: "center",

      fontSize: 14
    });
    let xRenderer = xAxis.get("renderer");
    xRenderer.labels.template.setAll({
      textAlign: "center",

      fontSize: 14
    });

    function makeSeries(name, fieldName) {
      let series = chart.series.push(
        am5xy.ColumnSeries.new(root, {
          name: name,
          xAxis: xAxis,
          yAxis: yAxis,
          valueYField: fieldName,
          categoryXField: "category"
        })
      );

      series.columns.template.setAll({
        tooltipText: "{name}, {categoryX}:{valueY}",
        showTooltipOn: "always",
        width: am5.percent(90),
        tooltipY: am5.percent(5)
      });
      let tooltip = am5.Tooltip.new(root, {});
      tooltip.label.setAll({
        fontSize: 14
      });

      series.set("tooltip", tooltip);
      series.data.setAll(data);
      series.appear();

      series.bullets.push(function() {
        return am5.Bullet.new(root, {
          locationY: 0,
          sprite: am5.Label.new(root, {
            text: "{valueY}",
            fill: root.interfaceColors.get("alternativeText"),
            centerY: 0,
            centerX: am5.p50,
            populateText: true,
            fontSize: 12
          })
        });
      });
      legend.data.push(series);
    }

    makeSeries("Plan", "plan");
    makeSeries("Actual", "actual");
    chart.appear(1000, 100);
  }

  RenderPlanVsActualChart(Chart1) {
    am4core.useTheme(am4themes_animated);

    am4core.options.commercialLicense = true;
    let chart = am4core.create("chartdiv", am4charts.XYChart3D);
    chart.exporting.menu = new am4core.ExportMenu();
    chart.exporting.menu.align = "right";
    chart.exporting.menu.verticalAlign = "top";
    chart.data = Chart1;

    let title = chart.titles.create();
    title.text = "BIS Certification - Plan Vs Actual Current FY";
    title.fontSize = 16;
    title.marginBottom = 30;

    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "category";
    categoryAxis.renderer.grid.template.location = 0;
    categoryAxis.renderer.minGridDistance = 20;
    categoryAxis.renderer.cellStartLocation = 0.1;
    categoryAxis.renderer.cellEndLocation = 0.9;

    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.min = 0;
    function createSeries(field, name, color) {
      let series = chart.series.push(new am4charts.ColumnSeries3D());
      series.dataFields.valueY = field;
      series.dataFields.categoryX = "category";
      series.name = name;
      series.columns.template.tooltipText = "[bold]{name}:{valueY}[/]";
      series.columns.template.width = am4core.percent(70);
      var bullet = series.bullets.push(new am4charts.LabelBullet());
      bullet.interactionsEnabled = false;
      bullet.dy = -4;
      bullet.dx = 0;
      bullet.label.text = "{valueY}";
      bullet.label.fontSize = 9;
      bullet.label.fill = am4core.color("#fff");
      bullet.label.background.fill = am4core.color("#2c2929b3");
      bullet.label.padding(1, 3, 1, 3);
      bullet.label.background.stroke = am4core.color("#00629d");
      bullet.label.background.strokeOpacity = 1;
      var colorValue = am4core.color(color);
      series.fill = colorValue;
      series.columns.template.fillOpacity = 0.5;
    }

    createSeries("plan", "Plan", "#2776BD");
    createSeries("actual", "Actual", "#00d600");
    chart.legend = new am4charts.Legend();
  }

  RenderLastThreeYearChart1(Chart2) {
    let root = am5.Root.new("chartdiv1");
    root._logo.dispose();
    root.setThemes([am5themes_Animated.new(root)]);

    let chart = root.container.children.push(
      am5xy.XYChart.new(root, {
        panX: false,
        panY: false,
        wheelX: "panX",
        wheelY: "zoomX",
        layout: root.verticalLayout
      })
    );
    chart
      .get("colors")
      .set("colors", [
        am5.color(0x67b7dc),
        am5.color(0x6794dc),
        am5.color(0x6771dc)
      ]);

    let data = Chart2;

    let xAxis = chart.xAxes.push(
      am5xy.CategoryAxis.new(root, {
        categoryField: "fy",
        renderer: am5xy.AxisRendererX.new(root, {}),
        tooltip: am5.Tooltip.new(root, {})
      })
    );

    xAxis.data.setAll(data);

    let yAxis = chart.yAxes.push(
      am5xy.ValueAxis.new(root, {
        min: 0,
        max: 100,
        strictMinMax: true,
        calculateTotals: true,
        renderer: am5xy.AxisRendererY.new(root, {})
      })
    );

    let legend = chart.children.push(
      am5.Legend.new(root, {
        centerX: am5.p50,
        x: am5.p50
      })
    );

    function makeSeries(name, fieldName) {
      let series = chart.series.push(
        am5xy.ColumnSeries.new(root, {
          name: name,
          stacked: true,
          xAxis: xAxis,
          yAxis: yAxis,
          valueYField: fieldName,
          categoryXField: "fy"
        })
      );

      series.columns.template.setAll({
        tooltipText: "{name}, {categoryX}:{valueY}",
        tooltipY: am5.percent(10)
      });
      series.data.setAll(data);
      series.appear();

      series.bullets.push(function() {
        return am5.Bullet.new(root, {
          sprite: am5.Label.new(root, {
            fill: root.interfaceColors.get("alternativeText"),
            centerY: am5.p50,
            centerX: am5.p50,
            populateText: true
          })
        });
      });

      legend.data.push(series);
    }

    makeSeries("Mini PC", "mini PC");
    makeSeries("NB", "nb");
    makeSeries("WS", "ws");

    chart.appear(1000, 100);
  }

  RenderLastThreeYearChart(Chart2) {
    debugger
    am4core.useTheme(am4themes_animated);

    am4core.options.commercialLicense = true;

    am4core.options.autoSetClassName = true;

    var chart = am4core.create("chartdiv1", am4charts.XYChart3D);
    
    chart.colors.step = 2;

    chart.legend = new am4charts.Legend();
    chart.legend.position = "bottom";
    chart.legend.paddingBottom = 0;
    chart.legend.labels.template.maxWidth = 95;
    chart.exporting.menu = new am4core.ExportMenu();
    chart.exporting.menu.align = "right";
    chart.exporting.menu.verticalAlign = "top";
   
   

    let title = chart.titles.create();
    title.text = " Plant BIS Certification - Year Wise ";
    title.fontSize = 16;
    title.marginBottom = 30;

    var xAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    xAxis.dataFields.category = "fy";
    xAxis.renderer.cellStartLocation = 0.1;
    xAxis.renderer.cellEndLocation = 0.9;
    xAxis.renderer.grid.template.location = 0;

    var yAxis = chart.yAxes.push(new am4charts.ValueAxis());
    yAxis.renderer.inside = false;
    yAxis.renderer.labels.template.disabled = true;
    yAxis.min = 0;
    yAxis.extraMax = 0.1;
    yAxis.calculateTotals = true;

    function createSeries(value, name,color) {
  
      // Set up series
      var series = chart.series.push(new am4charts.ColumnSeries3D());
      series.columns.template.width = am4core.percent(40);
      series.columns.template.tooltipText = "{name}: {valueY}";
      series.name = name;
      series.dataFields.categoryX = "fy";
      series.dataFields.valueY = value;
      var colorValue = am4core.color(color);
      series.fill = colorValue;
      series.stroke = am4core.color("white");
      series.stacked = true;
      series.tooltip.pointerOrientation = "vertical";
     
   
      return series;
    }
   
    chart.data = Chart2;
    
    createSeries("nb", "NB", "#FFC410");
    createSeries("mini PC", "Mini PC", "#2776BD");
    createSeries("ws", "WS", "#54B266");
// Create series for total
var totalSeries = chart.series.push(new am4charts.ColumnSeries3D());
totalSeries.columns.template.width = am4core.percent(40);
totalSeries.dataFields.valueY = "none";
totalSeries.dataFields.categoryX = "fy";
totalSeries.stacked = true;
totalSeries.hiddenInLegend = true;
totalSeries.columns.template.strokeOpacity = 0;
var colorValue = am4core.color("#54B266");
totalSeries.fill = colorValue;

var totalBullet = totalSeries.bullets.push(new am4charts.LabelBullet());
totalBullet.dy = -10;
totalBullet.label.text = "[bold]{fyTotal}";
totalBullet.label.fontSize = 12;
totalBullet.label.fill = am4core.color("#fff");
totalBullet.label.background.fill = am4core.color("#2c2929b3");
totalBullet.label.padding(1, 3, 1, 3);
totalBullet.label.background.stroke = am4core.color("#00629d");
totalBullet.label.background.strokeOpacity = 1;

  }

  RenderFYGrantedChart1(Chart3) {
    let roots = am5.Root.new("chartdiv2");
    roots._logo.dispose();

    roots.setThemes([am5themes_Animated.new(roots)]);

    let charts = roots.container.children.push(
      am5xy.XYChart.new(roots, {
        panX: false,
        panY: false,
        wheelX: "panX",
        wheelY: "zoomX",
        layout: roots.verticalLayout
      })
    );
    charts.get("colors").set("colors", [am5.color(0x70ad47)]);

    let data = Chart3;

    let xAxiss = charts.xAxes.push(
      am5xy.CategoryAxis.new(roots, {
        categoryField: "days",

        renderer: am5xy.AxisRendererX.new(roots, {}),
        tooltip: am5.Tooltip.new(roots, {})
      })
    );
    let xRenderers = xAxiss.get("renderer");
    xRenderers.labels.template.setAll({
      textAlign: "center",

      fontSize: 14
    });
    xAxiss.data.setAll(data);

    let yAxiss = charts.yAxes.push(
      am5xy.ValueAxis.new(roots, {
        renderer: am5xy.AxisRendererY.new(roots, {}),
        maxDeviation: 0.4
      })
    );
    xAxiss.get("renderer").labels.template.setAll({
      oversizedBehavior: "wrap",
      maxWidth: 150,
      textAlign: "center"
    });
    let yRenderers = yAxiss.get("renderer");
    yRenderers.labels.template.setAll({
      textAlign: "center",

      fontSize: 14
    });
    // Add legend

    let legends = charts.children.push(
      am5.Legend.new(roots, {
        centerX: am5.p50,
        x: am5.p50
      })
    );

    legends.labels.template.setAll({
      fontSize: 14
    });
    // Add series

    function makeSeriess(name, fieldName) {
      let seriess = charts.series.push(
        am5xy.ColumnSeries.new(roots, {
          name: name,
          stacked: false,
          xAxis: xAxiss,
          yAxis: yAxiss,
          valueYField: fieldName,
          categoryXField: "days"
        })
      );

      seriess.columns.template.setAll({
        tooltipText: "{name},  {categoryX}:{valueY}",
        tooltipY: am5.percent(10)
      });

      let tooltip = am5.Tooltip.new(roots, {});
      tooltip.label.setAll({
        fontSize: 14
      });

      seriess.set("tooltip", tooltip);
      seriess.data.setAll(data);

      seriess.appear();

      seriess.bullets.push(function() {
        return am5.Bullet.new(roots, {
          sprite: am5.Label.new(roots, {
            text: "{valueY}",
            fill: roots.interfaceColors.get("alternativeText"),
            centerY: am5.p50,
            centerX: am5.p50,
            populateText: true,
            fontSize: 12,
            textAlign: "center"
          })
        });
      });

      legends.data.push(seriess);
    }

    makeSeriess("Granted", "granted");

    charts.appear(1000, 100);
  }

  RenderFYGrantedChart(Chart3) {
    am4core.useTheme(am4themes_animated);

    let chart = am4core.create("chartdiv2", am4charts.XYChart3D);

    chart.data = Chart3;

    chart.exporting.menu = new am4core.ExportMenu();
    chart.exporting.menu.align = "right";
    chart.exporting.menu.verticalAlign = "top";
    chart.legend = new am4charts.Legend();
    chart.legend.position = "bottom";

    chart.legend.paddingBottom = 0;
    chart.legend.labels.template.maxWidth = 95;

    let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryAxis.dataFields.category = "days";
    categoryAxis.renderer.labels.template.hideOversized = false;
    categoryAxis.renderer.minGridDistance = 40;

    categoryAxis.renderer.labels.template.horizontalCenter = "middle";
    categoryAxis.renderer.labels.template.verticalCenter = "middle";
    let title = chart.titles.create();
    title.text = "BIS Granted Current FY ";
    title.fontSize = 16;
    title.marginBottom = 30;
    let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
    valueAxis.title.text = "No of Product";

    let series = chart.series.push(new am4charts.ColumnSeries3D());
    series.dataFields.valueY = "granted";
    series.columns.template.width = am4core.percent(40);
    series.dataFields.categoryX = "days";
    series.name = "Granted";
    series.tooltip.autoTextColor = false;
    series.tooltip.label.fill = am4core.color("#1d211e");

    series.tooltip.getFillFromObject = false;
    series.tooltip.label.propertyFields.fill = "#1d211e";
    series.tooltip.background.propertyFields.stroke = "#1d211e";

    series.tooltip.background.fill = am4core.color("#CEB1BE");

    var bullet = series.bullets.push(new am4charts.LabelBullet());
    bullet.interactionsEnabled = false;
    bullet.dy = -6;
    bullet.dx = 0;
    bullet.label.text = "{valueY}";
    bullet.label.fontSize = 10;
    bullet.label.fill = am4core.color("#fff");
    bullet.label.background.fill = am4core.color("#2c2929b3");
    bullet.label.padding(2, 4, 2, 4);
    bullet.label.background.stroke = am4core.color("#fff");
    bullet.label.background.strokeOpacity = 1;

    chart.colors.list = [
      am4core.color("#00d600"),
      am4core.color("#00d600"),
      am4core.color("#00d600")
    ];

    let columnTemplate = series.columns.template;
    columnTemplate.strokeWidth = 2;
    columnTemplate.strokeOpacity = 1;
    columnTemplate.stroke = am4core.color("#FFFFFF");

    columnTemplate.adapter.add("fill", function(fill, target) {
      return chart.colors.getIndex(target.dataItem.index);
    });

    columnTemplate.adapter.add("stroke", function(stroke, target) {
      return chart.colors.getIndex(target.dataItem.index);
    });

    chart.cursor = new am4charts.XYCursor();
    chart.cursor.lineX.strokeOpacity = 0;
    chart.cursor.lineY.strokeOpacity = 0;
  }

  GrantedandLabMasterLists() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.GrantedandLabMasterList(this.jsonParam).subscribe(response => {
      this.BISGrantedList = response.responseGrantedReports;
      this.BISLabTestReportList = response.responseLabTestReports;

      console.log(this.BISGrantedList);
      console.log(this.BISLabTestReportList);
    });
  }
  GetBISPendingInclusions() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };

    this.service.GetBISPendingInclusion(this.jsonParam).subscribe(response => {
      this.BISPendingList = response;

      console.log(this.BISPendingList);
    });
  }
  onfilter() {
    this.jsonParam = {
      category: this.category,
      product: this.form.product,
      modelForBis: this.form.modelForBis,
      seriesModel: this.form.seriesModel,
      status: this.form.status,
      fy: this.form.fy,
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };

    this.service.ProductByFilters(this.jsonParam).subscribe(
      response => {
        this.GrantedFull = response.table;
        this.GrantedFulls = this.GrantedFull;
        console.log(this.GrantedFull);
      },
      error => {
        this.authService.logout();
      }
    );
  }
  ProductFilterss(param: string) {
    this.jsonParam = {
      ProductId: 0,
      ProductName: param,
      PlantId: localStorage.getItem("PlantId"),
      MfgPlantID: 1
    };

    this.service.ProductFilters(this.jsonParam).subscribe(response => {
      this.GetBISProduct = response;
      this.BISProduct = this.GetBISProduct.table;
      this.BISModel = this.GetBISProduct.table1;
      this.BISSeries = this.GetBISProduct.table2;
      this.BISStatus = this.GetBISProduct.table3;
      this.BISYear = this.GetBISProduct.table4;
      console.log(this.GetBISProduct);
      console.log(this.BISProduct);
      console.log(this.BISProduct1);
      console.log(this.BISProduct2);
    });
  }
  BISProduct1(BISProduct1: any) {
    throw new Error("Method not implemented.");
  }
  isDisabled(): boolean {
    this.RoleId = localStorage.getItem("RoleID");
    if (this.RoleId == "3") {
      return true;
    } else {
      return false;
    }
  }
  GetStatusCount() {
    debugger
    this.jsonParam = {
   plantId: localStorage.getItem("PlantId"),

    };

    this.service.GetPendingPaymentStatusCount(this.jsonParam).subscribe(
      response => {
        this.paycount = response.table;

      },
      error => {
        this.authService.logout();
      }
    );
  }
  GetStatusByCount(param:any) {
    debugger
    this.jsonParam = {
   plantId: localStorage.getItem("PlantId"),
   status:param

    };

    this.service.GetPendingPaymentStatusByCount(this.jsonParam).subscribe(
      response => {
        this.payBycount = response.table;

      },
      error => {
        this.authService.logout();
      }
    );
  }
  GetBISQueryStatusCount() {
    debugger
    this.jsonParam = {
   plantId: localStorage.getItem("PlantId"),

    };

    this.service.GetBISQueryCount(this.jsonParam).subscribe(
      response => {
        this.BISQueryCount = response.table;

      },
      error => {
        this.authService.logout();
      }
    );
  }
  GetBISQueryStatusByCount(param:any) {
    debugger
    this.jsonParam = {
   plantId: localStorage.getItem("PlantId"),
   status:param

    };

    this.service.GetBISQueryByCount(this.jsonParam).subscribe(
      response => {
        this.BISQueryBycount = response.table;

      },
      error => {
        this.authService.logout();
      }
    );
  }
  ngOnInit() {
    this.spinner.show();
    this.GetOperativeLicenseList();
    this.ManageDataByPlant();
    this.RoleId = localStorage.getItem("RoleID");
    setTimeout(() => {
      this.spinner.hide();
    }, 4000);
    this.GetBISPendingInclusions();
    this.GrantedandLabMasterLists();
    this.elem = document.documentElement;
    this.chkScreenMode();
    this.openFullscreen();
    this.getSomePrivateStuff();
    this.getDashboardData();
    this.EnableAppHeaderMenuList();
    this.GetStatusCount();
    this.GetBISQueryStatusCount();
   
    (function($) {
      $(document).ready(function() {
        $("#kt_carousel_1_carousel").carousel();
      });
    })(jQuery);
    this.EnableAppHeaderMenuList();
    this.PlantId = localStorage.getItem("PlantId");
    let type = this.activatedRoute.snapshot.params["type"];

    this.activatedRoute.paramMap.subscribe(params => {
      type = params.get("type");
      console.log(type);
      if (type == "Notebook") {
        this.category = "Notebook";
      } else if (type == "DeskTop") {
        this.category = "Mini PC (ADPM)";
      } else if (type == "WorkStation") {
        this.category = "Workstation (ADPM)";
      }

      this.ProductFilterss(this.category);
    });
  }

  fullscreenmodes(event: any) {
    this.chkScreenMode();
  }
  chkScreenMode() {
    if (document.fullscreenElement) {
      this.isFullScreen = true;
    } else {
      this.isFullScreen = false;
    }
  }

  openFullscreen() {
    if (this.elem.requestFullscreen) {
      this.elem.requestFullscreen();
    } else if (this.elem.mozRequestFullScreen) {
      /* Firefox */
      this.elem.mozRequestFullScreen();
    } else if (this.elem.webkitRequestFullscreen) {
      /* Chrome, Safari and Opera */
      this.elem.webkitRequestFullscreen();
    } else if (this.elem.msRequestFullscreen) {
      /* IE/Edge */
      this.elem.msRequestFullscreen();
    }
  }

  /* Close fullscreen */
  closeFullscreen() {
    if (this.document.exitFullscreen) {
      this.document.exitFullscreen();
    } else if (this.document.mozCancelFullScreen) {
      /* Firefox */
      this.document.mozCancelFullScreen();
    } else if (this.document.webkitExitFullscreen) {
      /* Chrome, Safari and Opera */
      this.document.webkitExitFullscreen();
    } else if (this.document.msExitFullscreen) {
      /* IE/Edge */
      this.document.msExitFullscreen();
    }
  }

  EnableAppHeaderMenuList() {
    this.service.EnableHeaderMenuList();
  }

  ProductByCategory(param: any) {
    this.service.ProductByCategory(param);
  }

  getDashboardData() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.getDashboardData(this.jsonParam).subscribe(
      response => {
        console.log(response);
        if (response.resDashboardBoxs.length > 0) {
          this.DashboardList = response;
          this.DashboardBoxList = this.DashboardList.resDashboardBoxs;
          this.DashboardTilesList = this.DashboardList.resDashboardTiless;

          if (!this.DashboardBoxList[2].baseData) {
            this.Notebook_Box = null;
          } else {
            this.Notebook_Box = this.DashboardBoxList[2].baseData;
          }

          if (!this.DashboardBoxList[3].baseData) {
            this.WS_Box = null;
          } else {
            this.WS_Box = this.DashboardBoxList[3].baseData;
          }

          if (!this.DashboardBoxList[1].baseData) {
            this.MiniPC_Box = null;
          } else {
            this.MiniPC_Box = this.DashboardBoxList[1].baseData;
          }

          console.log(this.DashboardBoxList);
          console.log(this.DashboardTilesList);
        }
      },
      error => {
        this.authService.logout();
      }
    );
  }
  closemodal(){
    this.searchText="";
  }
  getSomePrivateStuff() {
    //
    this.model.action = "stuff";
    this.authService.getData().subscribe(
      response => {
        console.log(response);
        if (response.length > 0) {
          this.ProductList = response;
        }
      },
      error => {
        this.authService.logout();
      }
    );
  }

  logout() {
    this.authService.logout();
  }
}
