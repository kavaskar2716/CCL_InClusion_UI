import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild
} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription } from "rxjs";
import {
  ProgressStatus,
  ProgressStatusEnum
} from "src/app/model/progress-status.model";
import { NotificationService } from "src/app/notification.service";
import { SharedService } from "src/app/shared.service";
import { AuthService } from "src/app/_services/auth.service";
import { MatAccordion } from "@angular/material/expansion";
import Swal from "sweetalert2";
@Component({
  selector: "app-user-module",
  templateUrl: "./user-module.component.html",
  styleUrls: ["./user-module.component.css"]
})
export class UserModuleComponent implements OnInit {
  @ViewChild(MatAccordion) accordion: MatAccordion;
  @Input() public disabled: boolean;
  @Output() public uploadStatus: EventEmitter<ProgressStatus>;
  @ViewChild("inputFile") inputFile: ElementRef;
  public form: {
    sNo: any;
    userID: any;
    username: string;
    email: string;
    activeStatus: any;
    roleID: any;
    plant: any;
    createdBy: string;
    createdOn: string;
  };

  fileToUpload: any;
  status: any = "";
  shared: any;
  formgroup: any;
  SharedService: any;
  message: string;
  isActiveDiv: boolean;
  OperatingMasterLists: any;
  fileName: string;
  BISNotificationList: any;
  jsonParam: any = [];
  DelDataByTables: any;
  UserModuleListList: any;
  UserModuleList: any;
  PlantId: string;
  UserName: string;
  //machineDisabled: boolean | undefined;

  constructor(
    private authService: AuthService,
    private service: SharedService,
    private notifyService: NotificationService,
    private activatedRoute: ActivatedRoute,

    private router: Router
  ) {
    this.form = {
      sNo: "",
      userID: "",
      username: "",
      email: "",
      activeStatus: "",
      roleID: "",
      plant: "",
      createdBy: "",
      createdOn: ""
    };
  }

  public subsVar: Subscription | undefined;
  ngOnInit(): void {
    this.EnableAppHeaderMenuList();
    this.PlantId = localStorage.getItem("PlantId");
    this.UserName = localStorage.getItem("name");
    let type = this.activatedRoute.snapshot.params["type"];
    this.GetUserModuleList();

    this.form.userID = 0;
  }

  GetUserModuleList() {
    this.service.ManageUserModuleList().subscribe(response => {
      this.UserModuleList = response;
    });
  }
  PostDelDataByTables(param: any) {
    this.jsonParam = {
      delId: param,
      str: "BISUser",
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.PostDelDataByTable(this.jsonParam).subscribe(response => {
      this.DelDataByTables = response;
      console.log(this.DelDataByTables);
      if ((response.success = "DeleteSuccess")) {
        Swal.fire("Great!", "Delete Successfully!", "success");
        this.GetUserModuleList();
      }
    });
  }
  EditUserMaster(element: any) {
    debugger;
    this.isActiveDiv = true;
    this.form.sNo = element.sNo;
    this.form.userID = element.userID;
    this.form.username = element.username;
    this.form.email = element.email;
    this.form.activeStatus = element.activeStatus;
    this.form.roleID = element.roleID;
    this.form.plant = element.plantId;
    this.form.createdBy = element.createdBy;
    this.form.createdOn = element.createdOn;
  }

  public UserApplication() {
    debugger;
    this.jsonParam = {
      userID: this.form.userID,
      username: this.form.username,
      email: this.form.email,
      activeStatus: this.form.activeStatus,
      roleID: this.form.roleID,
      plant: this.form.plant,
      createdBy: localStorage.getItem("name"),
      PlantId: this.form.plant
    };
    this.service.UserApplication(this.jsonParam).subscribe(data => {
      console.log(data);
      this.service.UserApplication(this.jsonParam).subscribe(response => {
        this.UserModuleList = response;
      });
      Swal.fire("Great!", "Data Created Successfully!", "success");
    });

    this.form = {
      sNo: "",
      userID: "",
      username: "",
      email: "",
      activeStatus: "",
      roleID: "",
      plant: "",
      createdBy: "",
      createdOn: ""
    };
  }

  EnableAppHeaderMenuList() {
    this.service.EnableHeaderMenuList();
  }
  home() {
    this.router.navigate(["/dashboard"]);
  }
  resetForm() {


   
    
    this.form = {
      sNo: "",
      userID: "",
      username: "",
      email: "",
      activeStatus: "",
      roleID: "",
      plant: "",
      createdBy: "",
      createdOn: ""
    };

    
  }
  ngAfterViewInit() {}
  handleClear() {
    this.form.userID = "";
    this.form.username = "";
    this.form.email = "";
    this.form.activeStatus = "";
    this.form.roleID = "";
    this.form.plant = "";
  }
}
