import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { AuthService } from "src/app/_services/auth.service";
import { NotificationService } from "src/app/notification.service";
import { SharedService } from "src/app/shared.service";
import { Router } from "@angular/router";
import * as _ from "lodash";
import { ActivatedRoute } from "@angular/router";
import * as XLSX from "xlsx";

@Component({
  selector: "app-searchbyproduct",
  templateUrl: "./searchbyproduct.component.html",
  styleUrls: ["./searchbyproduct.component.css"]
})
export class SearchbyproductComponent implements OnInit {
  @ViewChild("TABLE", { static: false }) TABLE: ElementRef;
  @ViewChild("TABLE1", { static: false }) TABLE1: ElementRef;
  ProductItemList: any;
  searchText;
  searchText1;
  jsonParam: any;
  PlantId: string;
  form: any;
  ProductItemLists: any;
  GetBISProduct: any;
  BISProduct: any;
  BISModel: any;
  BISSeries: any;
  BISStatus: any;
  BISYear: any;
  BISProduct1: any;
  BISProduct2: any;
  BISCategory: any;
  BISMfg: any;
  MFGName: any;
  MFGModalForBis: any;
  Result: string;
  GetResult: string;
  GetBISProductListByParam: any;
  GetBISProductByFY: any;
  constructor(
    private authService: AuthService,
    private service: SharedService,
    private notifyService: NotificationService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {
    this.form = {
      category: "",
      product: "",
      modelForBis: "",
      series_Model: "",
      status: "",
      plantId: "",
      fy: "",
      mfgName: 1
    };

    this.Result = "WIP";
  }

  GetModalForBis(param: any) {
    this.jsonParam = {
      model_For_BIS: param
    };
    this.service.GetMfgModalForBis(this.jsonParam).subscribe(
      response => {
        this.MFGModalForBis = response.table;
        console.log(this.MFGModalForBis);
      },
      error => {
        this.authService.logout();
      }
    );
  }
  ngOnInit(): void {
    this.BISProgramMasterLists();
    this.TradingProductFilter();
    this.PlantId = localStorage.getItem("PlantId");
  }
  TradingProductFilter() {

    debugger;

    this.jsonParam = {

      PlantId: localStorage.getItem("PlantId")

    };



    this.service.ProductCommonFilters(this.jsonParam).subscribe(response => {

      debugger;

      this.GetBISProduct = response;



      this.BISProduct = this.GetBISProduct.table;

      this.BISModel = this.GetBISProduct.table1;

      this.BISSeries = this.GetBISProduct.table2;

      this.BISStatus = this.GetBISProduct.table3;

      this.BISCategory = this.GetBISProduct.table4;

      this.BISYear = this.GetBISProduct.table6;

      this.BISMfg = this.GetBISProduct.table5;

      console.log(this.GetBISProduct);

    });

  }
  GetProdListByFY(param: any) {
    debugger;
    this.form.product = "";
    this.form.modelForBis = "";
    this.form.series_Model = "";
    this.jsonParam = {
      fy: param,
      Category: "NULL",
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 0
    };
    debugger;
    this.service.GetBISProdListByFY(this.jsonParam).subscribe(
      response => {
        this.GetBISProductByFY = response;
        this.BISProduct = this.GetBISProductByFY.table1;
        this.BISModel = this.GetBISProductByFY.table2;
        this.BISSeries = this.GetBISProductByFY.table3;
        console.log(this.GetBISProductByFY);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetKeyFiltersBy_category() {
    debugger;
    this.form.product = "";
    this.form.modelForBis = "";
    this.form.series_Model = "";
    this.jsonParam = {
      category: this.form.category,
      product: "",
      modelForBis: "",
      seriesModel: "",
      status: "",
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1,
      fy: this.form.fy
    };
    debugger;
    this.service.GetBISKeyFiltersBy_Param(this.jsonParam).subscribe(
      response => {
        debugger;
        this.GetBISProductListByParam = response;
        this.BISProduct = this.GetBISProductListByParam.table2;
        this.BISModel = this.GetBISProductListByParam.table3;
        this.BISSeries = this.GetBISProductListByParam.table4;
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetKeyFiltersBy_Product() {
    debugger;
    this.form.modelForBis = "";
    this.form.series_Model = "";
    this.jsonParam = {
      category: this.form.category,
      product: this.form.product,
      modelForBis: "",
      seriesModel: "",
      status: "",
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1,
      fy: this.form.fy
    };
    debugger;
    this.service.GetBISKeyFiltersBy_Param(this.jsonParam).subscribe(
      response => {
        debugger;
        this.GetBISProductListByParam = response;
        this.BISModel = this.GetBISProductListByParam.table3;
        this.BISSeries = this.GetBISProductListByParam.table4;
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetKeyFiltersBy_Model() {
    debugger;

    this.jsonParam = {
      category: this.form.category,
      product: this.form.product,
      modelForBis: this.form.modelForBis,
      seriesModel: "",
      status: "",
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1,
      fy: this.form.fy
    };
    debugger;
    this.service.GetBISKeyFiltersBy_Param(this.jsonParam).subscribe(
      response => {
        debugger;
        this.GetBISProductListByParam = response;
        this.BISSeries = this.GetBISProductListByParam.table4;
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  onfilter() {
    this.jsonParam = {
      category: this.form.category,
      product: this.form.product,
      modelForBis: this.form.modelForBis,
      seriesModel: this.form.series_Model,
      status: this.form.status,
      fy: this.form.fy,
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };
    debugger;
    this.service.ProductByFilters(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response.table;
        this.ProductItemLists = this.ProductItemList;
        console.log(this.ProductItemList);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  ClearFilter() {
    this.form.fy = "";
    this.form.category = "";
    this.form.modelForBis = "";
    this.form.series_Model = "";
    this.form.product = "";
    this.form.status = "";

    this.ProductItemList = null;
  }
  BISProgramMasterLists() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.BISProgramMasterList(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response;

        console.log(this.ProductItemList);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  EnableAppHeaderMenuList() {
    this.service.EnableHeaderMenuList();
  }
  home() {
    this.router.navigate(["/dashboard"]);
  }

  ExportTOMfg() {
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(
      this.TABLE1.nativeElement,
      { raw: true }
    );
    const wb: XLSX.WorkBook = XLSX.utils.book_new();

    ws["A1"].s = {
      fill: {
        patternType: "none",
        fgColor: { rgb: "FF000000" },
        bgColor: { rgb: "FFFFFFFF" }
      },
      font: {
        name: "Times New Roman",
        sz: 16,
        color: { rgb: "#FF000000" },
        bold: true,
        italic: false,
        underline: false
      },
      border: {
        top: { style: "thin", color: { auto: 1 } },
        right: { style: "thin", color: { auto: 1 } },
        bottom: { style: "thin", color: { auto: 1 } },
        left: { style: "thin", color: { auto: 1 } }
      }
    };
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
    XLSX.writeFile(wb, "Excelreport.xlsx");
  }
  ExportTOExcel() {
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(
      this.TABLE.nativeElement,
      { raw: true }
    );
    const wb: XLSX.WorkBook = XLSX.utils.book_new();

    ws["A1"].s = {
      fill: {
        patternType: "none",
        fgColor: { rgb: "FF000000" },
        bgColor: { rgb: "FFFFFFFF" }
      },
      font: {
        name: "Times New Roman",
        sz: 16,
        color: { rgb: "#FF000000" },
        bold: true,
        italic: false,
        underline: false
      },
      border: {
        top: { style: "thin", color: { auto: 1 } },
        right: { style: "thin", color: { auto: 1 } },
        bottom: { style: "thin", color: { auto: 1 } },
        left: { style: "thin", color: { auto: 1 } }
      }
    };
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
    XLSX.writeFile(wb, "Excelreport.xlsx");
  }
}
