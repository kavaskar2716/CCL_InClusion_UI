import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ccl-program',
  templateUrl: './ccl-program.component.html',
  styleUrls: ['./ccl-program.component.css']
})
export class CclProgramComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
