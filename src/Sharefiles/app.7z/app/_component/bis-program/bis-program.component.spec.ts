import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BisProgramComponent } from './bis-program.component';

describe('BisProgramComponent', () => {
  let component: BisProgramComponent;
  let fixture: ComponentFixture<BisProgramComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BisProgramComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BisProgramComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
