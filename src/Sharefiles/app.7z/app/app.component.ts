import { DOCUMENT } from "@angular/common";
import {
  Component,
  OnInit,
  HostListener,
  Inject,
  ViewChild
} from "@angular/core";
import { SharedService } from "src/app/shared.service";
import { Observable, Subscription } from "rxjs";
import { Router } from "@angular/router";
import { Idle, DEFAULT_INTERRUPTSOURCES } from "@ng-idle/core";
import { Keepalive } from "@ng-idle/keepalive";
import { BsModalService } from "ngx-bootstrap/modal";
import { BsModalRef } from "ngx-bootstrap/modal";
import { ModalDirective } from "ngx-bootstrap/modal";
import { IdleServiceService } from "./idle-service.service";
import * as CryptoJS from 'crypto-js'; 
// import disableDevtool from 'disable-devtool';
// declare interface optionStatic {
//   md5?: string; // Bypass the disabled md5 value, see 3.2 for details, the bypass disable is not enabled by default
//   url?: string; // Jump to the page when closing the page fails, the default value is localhost
//   tkName?: string; // Bypass the url parameter name when disabled, the default is ddtk
//   ondevtoolopen?(type: DETECTOR_TYPE, next: Function): void; // Callback for opening the developer panel, the url parameter is invalid when it is enabled, and the type is the monitoring mode, see 3.5 for details
//   ondevtoolclose?(): void;
//   interval?: number; // Timer interval is 200ms by default
//   disableMenu?: boolean; // Whether to disable the right-click menu The default is true
//   clearIntervalWhenDevOpenTrigger?: boolean; // Whether to stop monitoring after triggering The default is false. This parameter is invalid when using ondevtoolclose
//   detactors?: Array<DETECTOR_TYPE>; // Enabled detectors For details of detectors, see 3.5. The default is all, it is recommended to use all
//   clearLog?: boolean; // Whether to clear the log every time
//   disableSelect?: boolean; // Whether to disable select text The default is true
//   disableCopy?: boolean; // Whether to disable copy text The default is true
//   disableCut?: boolean; // Whether to disable cut text The default is true
// }

// declare type DETECTOR_TYPE = -1 | 0 | 1 | 2 | 3 | 4 | 5; // For details of the detector, see 3.5
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {
  isShow: boolean;
  topPosToStartShowing = 100;
  idleState = "Not started.";
  timedOut = false;
  lastPing?: Date = null;
  public modalRef: BsModalRef;
  @ViewChild("childModal", { static: false }) childModal: ModalDirective;
  public sidebarShow: boolean = false;
  BISNotification: any;
  jsonParam: any;
  filterTerm!: string;
  elem: any;
  isFullScreen: boolean | undefined;
  PlantId: string;
  title: string;
  Roleid: string;

  constructor(
    private idle: Idle,
    private keepalive: Keepalive,
    private modalService: BsModalService,
    private IdleServiceService: IdleServiceService,
    private service: SharedService,
    private router: Router,
    @Inject(DOCUMENT) private document: any
  ) {
    idle.setIdle(360);

    idle.setTimeout(30);

    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    idle.onIdleEnd.subscribe(() => {
      this.idleState = "No longer idle.";
      console.log(this.idleState);
      this.reset();
    });

    idle.onTimeout.subscribe(() => {
      this.childModal.hide();
      this.idleState = "Timed out!";
      this.timedOut = true;
      console.log(this.idleState);
      this.router.navigate(["/"]);
      window.location.reload();
    });

    idle.onIdleStart.subscribe(() => {
      this.idleState = "You've gone idle!";
      console.log(this.idleState);
      this.childModal.show();
    });

    idle.onTimeoutWarning.subscribe(countdown => {
      this.idleState = "You will time out in " + countdown + " seconds!";
      console.log(this.idleState);
    });

    keepalive.interval(15);

    keepalive.onPing.subscribe(() => (this.lastPing = new Date()));

    this.IdleServiceService.getUserLoggedIn().subscribe(userLoggedIn => {
      if (userLoggedIn) {
        idle.watch();
        this.timedOut = false;
      } else {
        idle.stop();
      }
    });
  }
  reset() {
    this.idle.watch();

    this.timedOut = false;
  }

  hideChildModal(): void {
    this.childModal.hide();
  }

  stay() {
    this.childModal.hide();
    this.reset();
  }

  @HostListener("document:fullscreenchange", ["$event"])
  @HostListener("document:webkitfullscreenchange", ["$event"])
  @HostListener("document:mozfullscreenchange", ["$event"])
  @HostListener("document:MSFullscreenChange", ["$event"])
  ActivateList: boolean = false;

  public subsVar: Subscription | undefined;
  ngOnInit() {
    this.PlantId = localStorage.getItem("PlantId");

    if (localStorage.getItem("PlantId") == "1") {
      this.title = "PONDY";
    } else if (localStorage.getItem("PlantId") == "2") {
      this.title = "TRADING";
    } else {
      this.title = "";
    }
    this.elem = document.documentElement;
    if (this.service.subsVar) {
      this.subsVar = this.service.invokeAppComponentFunction.subscribe(res => {
        console.log(res);
        this.EnableMain();
        this.GetBISNotifications();
        this.reset();
        if (localStorage.getItem("PlantId") == "1") {
          this.title = " - PONDY";
        } else if (localStorage.getItem("PlantId") == "2") {
          this.title = " - TRADING";
        } else {
          this.title = "";
        }
        this.Roleid = localStorage.getItem("RoleID");
      });
    }
    // disableDevtool(
    //   {
    //     disableMenu: true,
    //     detectors: []
    //   }
    //   );
  }
  GetBISNotifications() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.GetBISNotification(this.jsonParam).subscribe(response => {
      this.BISNotification = response;
    });
  }
  fullscreenmodes(event: any) {
    this.chkScreenMode();
  }
  chkScreenMode() {
    if (document.fullscreenElement) {
      this.isFullScreen = true;
    } else {
      this.isFullScreen = false;
    }
  }

  openFullscreen() {
    if (this.elem.requestFullscreen) {
      this.elem.requestFullscreen();
    } else if (this.elem.mozRequestFullScreen) {
      /* Firefox */
      this.elem.mozRequestFullScreen();
    } else if (this.elem.webkitRequestFullscreen) {
      /* Chrome, Safari and Opera */
      this.elem.webkitRequestFullscreen();
    } else if (this.elem.msRequestFullscreen) {
      /* IE/Edge */
      this.elem.msRequestFullscreen();
    }
  }

  closeFullscreen() {
    if (this.document.exitFullscreen) {
      this.document.exitFullscreen();
    } else if (this.document.mozCancelFullScreen) {
      /* Firefox */
      this.document.mozCancelFullScreen();
    } else if (this.document.webkitExitFullscreen) {
      /* Chrome, Safari and Opera */
      this.document.webkitExitFullscreen();
    } else if (this.document.msExitFullscreen) {
      /* IE/Edge */
      this.document.msExitFullscreen();
    }
  }

  logout() {
    this.childModal.hide();
    this.IdleServiceService.setUserLoggedIn(false);
    localStorage.clear();
    this.router.navigate(["/auth/login"]);
    window.location.reload();
  }

  EnableMain() {
    this.ActivateList = true;
  }

  DisableMain() {
    this.ActivateList = false;
  }
}
