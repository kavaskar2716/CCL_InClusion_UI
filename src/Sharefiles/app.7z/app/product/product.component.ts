import { Component, OnInit } from "@angular/core";
import { AuthService } from "src/app/_services/auth.service";
import { Subscription } from "rxjs";
import { NotificationService } from "src/app/notification.service";
import { SharedService } from "src/app/shared.service";
import { Router } from "@angular/router";
import * as _ from "lodash";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-product",
  templateUrl: "./product.component.html",
  styleUrls: ["./product.component.css"]
})
export class ProductComponent implements OnInit {
  searchTerm: any;
  public filterTerm!: any;
  ProductItemList: any = [];
  param: any;
  jsonParam: any = [];
  ProductType: string = "";
  ProductItemLists: any = [];

  compid: any = "";
  machineid: any = "";
  marketingid: any = "";
  marketingfyid: any = "";
  status: any = "";
  machineDisabled: boolean = false;
  msDisabled: boolean = false;
  compDisabled: boolean = false;
  stsDisabled: boolean = false;
  BISMasterLists: any;
  table: any;
  Productdata: any;
  GetBISProduct: any;
  BISProduct: any;
  BISProduct1: any;
  BISProduct2: any;

  category: any;
  BISModel: any;
  BISLead: any;
  BISStatus: any;
  BISSeries: any;
  PlantId: string;
  BISYear: any;
  BISCategory: any;
  BISMfgId: any;
  form: any;
  GetBISProductByFY: any;
  GetBISProductListByParam: any;

  constructor(
    private authService: AuthService,
    private service: SharedService,
    private notifyService: NotificationService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {
    this.form = {
      category: "",
      product: "",
      modelForBis: "",
      seriesModel: "",
      status: "",
      plantId: "",
      fy: "",
      mfgPlantID: ""
    };
  }

  public subsVar: Subscription | undefined;

  ngOnInit(): void {
    this.EnableAppHeaderMenuList();
    this.PlantId = localStorage.getItem("PlantId");
    let type = this.activatedRoute.snapshot.params["type"];
    this.activatedRoute.paramMap.subscribe(params => {
      type = params.get("type");
      console.log(type);
      if (type == "Notebook") {
        this.category = "Notebook";
      } else if (type == "DeskTop") {
        this.category = "Mini PC (ADPM)";
      } else if (type == "WorkStation") {
        this.category = "Workstation (ADPM)";
      }

      this.ProductFilterss(this.category);
    });

    if (this.service.subsVar) {
      this.subsVar = this.service.invokeProductCategoryFunction.subscribe(
        (param: string) => {}
      );
    }
  }

  BISProgramMasterLists() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.BISProgramMasterList(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response;
        console.log(this.ProductItemList);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetProdListByFY(param: any) {
    debugger;
    this.form.product = "";
    this.form.modelForBis = "";
    this.form.seriesModel = "";
    this.jsonParam = {
      fy: param,
      Category: this.category,
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 0
    };
    debugger;
    this.service.GetBISProdListByFY(this.jsonParam).subscribe(
      response => {
        this.GetBISProductByFY = response;
        this.BISProduct = this.GetBISProductByFY.table1;
        this.BISModel = this.GetBISProductByFY.table2;
        this.BISSeries = this.GetBISProductByFY.table3;
        console.log(this.GetBISProductByFY);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetKeyFiltersBy_Product() {
    debugger;
    this.form.modelForBis = "";
    this.form.seriesModel = "";
    this.jsonParam = {
      category: this.category,
      product: this.form.product,
      modelForBis: "",
      seriesModel: "",
      status: "",
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1,
      fy: this.form.fy
    };
    debugger;
    this.service.GetBISKeyFiltersBy_Param(this.jsonParam).subscribe(
      response => {
        debugger;
        this.GetBISProductListByParam = response;
        this.BISModel = this.GetBISProductListByParam.table3;
        this.BISSeries = this.GetBISProductListByParam.table4;
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  GetKeyFiltersBy_Model() {
    debugger;

    this.jsonParam = {
      category: this.category,
      product: this.form.product,
      modelForBis: this.form.modelForBis,
      seriesModel: "",
      status: "",
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1,
      fy: this.form.fy
    };
    debugger;
    this.service.GetBISKeyFiltersBy_Param(this.jsonParam).subscribe(
      response => {
        debugger;
        this.GetBISProductListByParam = response;
        this.BISSeries = this.GetBISProductListByParam.table4;
        console.log(this.GetBISProductListByParam);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  ProductFilterss(param: string) {
    debugger;
    this.jsonParam = {
      ProductId: 0,
      ProductName: param,
      PlantId: localStorage.getItem("PlantId"),
      MfgPlantID: 1
    };

    this.service.ProductFilters(this.jsonParam).subscribe(response => {
      debugger;
      this.GetBISProduct = response;
      this.BISProduct = this.GetBISProduct.table;
      this.BISModel = this.GetBISProduct.table1;
      this.BISSeries = this.GetBISProduct.table2;
      this.BISStatus = this.GetBISProduct.table3;
      this.BISYear = this.GetBISProduct.table4;
      this.BISCategory = this.GetBISProduct.table5;
      this.BISMfgId = this.GetBISProduct.table6;
      console.log(this.GetBISProduct);
    });
  }

  onfilter() {
    this.jsonParam = {
      category: this.category,
      product: this.form.product,
      modelForBis: this.form.modelForBis,
      seriesModel: this.form.seriesModel,
      status: this.form.status,
      fy: this.form.fy,
      plantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };
    debugger;
    this.service.ProductByFilters(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response.table;
        this.ProductItemLists = this.ProductItemList;
        console.log(this.ProductItemList);

        this.form.nativeElement.value = " ";
      },
      error => {
        this.authService.logout();
      }
    );
  }

  fyfilter(_marketing: any) {
    this.jsonParam = {
      SearchStr: _marketing,
      Str: "PROD",
      category: this.category,
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };

    this.service.ProductByFilters(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response.table;
        this.ProductItemLists = this.ProductItemList;
        console.log(this.ProductItemList);
      },
      error => {
        this.authService.logout();
      }
    );
  }
  marketingfilterfy(_marketingfy: any) {
    this.machineDisabled = false;
    this.compDisabled = false;
    this.stsDisabled = false;

    this.jsonParam = {
      fy: _marketingfy,
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };

    this.service.ProductByFilters(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response.table;
        this.ProductItemLists = this.ProductItemList;
        console.log(this.ProductItemList);
      },
      error => {
        this.authService.logout();
      }
    );
  }
  marketingfilter(_marketing: any) {
    this.machineDisabled = false;
    this.compDisabled = false;
    this.stsDisabled = false;

    this.jsonParam = {
      product: _marketing,
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };

    this.service.ProductByFilters(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response.table;
        this.ProductItemLists = this.ProductItemList;
        console.log(this.ProductItemList);
      },
      error => {
        this.authService.logout();
      }
    );
  }
  compfilter(compid: any) {
    this.machineDisabled = false;
    this.compDisabled = false;
    this.stsDisabled = false;

    this.jsonParam = {
      modelForBis: compid,
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };

    this.service.ProductByFilters(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response.table;
        this.ProductItemLists = this.ProductItemList;
        console.log(this.ProductItemList);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  machinefilter(_machine: any) {
    this.jsonParam = {
      SearchStr: _machine,
      Str: "SM",
      category: this.category,
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };

    this.service.ProductByFilters(this.jsonParam).subscribe(
      response => {
        this.ProductItemList = response.table;
        this.ProductItemLists = this.ProductItemList;
        console.log(this.ProductItemList);
      },
      error => {
        this.authService.logout();
      }
    );
  }

  statusfilter(status: any) {
    this.jsonParam = {
      SearchStr: status,
      category: this.category,
      PlantId: localStorage.getItem("PlantId"),
      mfgPlantID: 1
    };
    this.service.ProductByFilters(this.jsonParam).subscribe(response => {
      debugger;
      this.ProductItemList = response.table;
      this.ProductItemLists = this.ProductItemList;
      console.log(this.ProductItemList);
    });
  }

  EnableAppHeaderMenuList() {
    this.service.EnableHeaderMenuList();
  }
  home() {
    this.router.navigate(["/dashboard"]);
  }

  ClearFilter() {
    this.machineDisabled = false;
    this.compDisabled = false;
    this.msDisabled = false;
    this.stsDisabled = false;
    this.form.fy = "";
    this.form.category = "";
    this.form.modelForBis = "";
    this.form.seriesModel = "";
    this.form.product = "";
    this.form.status = "";
    this.ProductItemList = null;
    this.GetProdListByFY("FY");
  }
}
