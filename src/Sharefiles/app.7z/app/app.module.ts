import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { MatIconModule } from "@angular/material/icon";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MatSliderModule } from "@angular/material/slider";
import { LoginComponent } from "./_component/login/login.component";
import { DashboardComponent } from "./_component/dashboard/dashboard.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { JwtModule } from "@auth0/angular-jwt";
import { ToastrModule } from "ngx-toastr";
import { SharedService } from "./shared.service";
import { BisNotificationComponent } from "./bis-notification/bis-notification.component";
import { ProductComponent } from "./product/product.component";
import { SearchFilterPipe } from "./search-filter.pipe";
import { NgxSpinnerModule } from "ngx-spinner";
import { MatTableModule } from "@angular/material/table";
import { MatListModule } from "@angular/material/list";
import { MatButtonModule } from "@angular/material/button";
import { MatTabsModule } from "@angular/material/tabs";
import { MatModule } from "./material-module";
import { BisProgramComponent } from "./_component/bis-program/bis-program.component";
import { OperatingLicenseComponent } from "./_component/operating-license/operating-license.component";
import { BisGrantedComponent } from "./_component/bis-granted/bis-granted.component";
import { UserModuleComponent } from "./_component/user-module/user-module.component";
import { CclProgramComponent } from "./_component/ccl-program/ccl-program.component";
import { TrackerComponent } from "./_component/tracker/tracker.component";
import { BisReportComponent } from "./_component/bis-report/bis-report.component";
import { PendingInclusionComponent } from "./_component/pending-inclusion/pending-inclusion.component";
import {
  DatePipe,
  HashLocationStrategy,
  LocationStrategy
} from "@angular/common";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatNativeDateModule } from "@angular/material/core";
import { NgIdleKeepaliveModule } from "@ng-idle/keepalive";
import { MomentModule } from "ngx-moment";

import { MatSelectModule } from '@angular/material/select';
import { ModalModule, BsModalService } from "ngx-bootstrap/modal";
import { MatInputModule } from "@angular/material/input";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MAT_DATE_FORMATS } from "@angular/material/core";
import { MatMomentDateModule } from "@angular/material-moment-adapter";
import { NgxUsefulSwiperModule } from "ngx-useful-swiper";
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatSidenavModule } from "@angular/material/sidenav";
import { SidebarModule } from "@syncfusion/ej2-angular-navigations";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { MatExpansionModule } from "@angular/material/expansion";
import { PoReferenceComponent } from "./_component/po-reference/po-reference.component";
import { SearchbyproductComponent } from "./_component/searchbyproduct/searchbyproduct.component";
import { TradingDashboardComponent } from "./_component/trading-dashboard/trading-dashboard.component";
import { IdleServiceService } from "./idle-service.service";
import { GuestComponent } from "./_component/guest/guest.component";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { ManageMfgComponent } from "./manage-mfg/manage-mfg.component";
import { PendingPaymentComponent } from "./_component/pending-payment/pending-payment.component";
import { BisQueryComponent } from "./_component/bis-query/bis-query.component";
import { NgxScrollTopModule } from 'ngx-scrolltop';
import { NgMultiSelectDropDownModule } from "ng-multiselect-dropdown";



const MY_FORMATS = {
  parse: {
    dateInput: "DD MMMM YYYY"
  },
  display: {
    dateInput: "DD MMMM YYYY",
    monthYearLabel: "MMMM YYYY",
    dateA11yLabel: "LL",
    monthYearA11yLabel: "MMMM YYYY"
  }
};
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    BisNotificationComponent,
    ProductComponent,
    SearchFilterPipe,
    OperatingLicenseComponent,
    BisProgramComponent,
    OperatingLicenseComponent,
    BisGrantedComponent,
    UserModuleComponent,
    CclProgramComponent,
    TrackerComponent,
    BisReportComponent,
    PendingInclusionComponent,
    PoReferenceComponent,
    SearchbyproductComponent,
    TradingDashboardComponent,
    GuestComponent,
    ManageMfgComponent,
    PendingPaymentComponent,
    BisQueryComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    SidebarModule,
    BrowserModule,
    ReactiveFormsModule,
    MatNativeDateModule,
    MatDatepickerModule,
    AppRoutingModule,
    MatExpansionModule,
    BrowserAnimationsModule,
    NgxUsefulSwiperModule,
    MatSelectModule,
    MatSliderModule,
    Ng2SearchPipeModule,
    MatIconModule,
    MatTableModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatButtonModule,
    MatTabsModule,
    NgbModule,
    FormsModule,
    MatModule,
    MatDatepickerModule,
    MatInputModule,
    MatFormFieldModule,
    NgIdleKeepaliveModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    MomentModule,
    ModalModule,
    MatMomentDateModule,
    NgxSpinnerModule,
    FormsModule,
    MatProgressSpinnerModule,
    HttpClientModule,
    NgbModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: () => {
          return localStorage.getItem("access_token");
        },
        allowedDomains: ["localhost"],
        disallowedRoutes: ["localhost/auth/login"]
      }
    }),
    ToastrModule.forRoot({
      closeButton: true,
      timeOut: 15000,
      progressBar: true
    }),
    NgxScrollTopModule
  ],
  providers: [
    SharedService,
    DatePipe,
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    BsModalService,
    IdleServiceService,
    { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
