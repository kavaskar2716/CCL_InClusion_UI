import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BisNotificationComponent } from './bis-notification.component';

describe('BisNotificationComponent', () => {
  let component: BisNotificationComponent;
  let fixture: ComponentFixture<BisNotificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BisNotificationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BisNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
