import { HttpEventType } from "@angular/common/http";
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild
} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription } from "rxjs";
import Swal from "sweetalert2";
import {
  ProgressStatus,
  ProgressStatusEnum
} from "../model/progress-status.model";
import { NotificationService } from "../notification.service";
import { SharedService } from "../shared.service";
import { AuthService } from "../_services/auth.service";
import { MatAccordion } from "@angular/material/expansion";

@Component({
  selector: "app-bis-notification",
  templateUrl: "./bis-notification.component.html",
  styleUrls: ["./bis-notification.component.css"]
})
export class BisNotificationComponent implements OnInit {
  @ViewChild(MatAccordion) accordion: MatAccordion;
  @Input() public disabled: boolean;
  @Output() public uploadStatus: EventEmitter<ProgressStatus>;
  @ViewChild("inputFile") inputFile: ElementRef;
  public form: {
    id: any;
    notification: string;
    status: string;
    createdBy: string;
    PlantId: string;
  };

  fileToUpload: any;
  status: any = "";
  shared: any;
  formgroup: any;
  SharedService: any;
  message: string;
  isActiveDiv: boolean;
  OperatingMasterLists: any;
  fileName: string;
  BISNotificationList: any;
  jsonParam: any = [];
  DelDataByTables: any;
  PlantId: string;
  Roleid: string;
  //machineDisabled: boolean | undefined;

  constructor(
    private authService: AuthService,
    private service: SharedService,
    private notifyService: NotificationService,
    private activatedRoute: ActivatedRoute,

    private router: Router
  ) {
    this.form = {
      id: "",
      notification: "",
      status: "",
      createdBy: "",
      PlantId: ""
    };
  }

  public subsVar: Subscription | undefined;
  ngOnInit(): void {
    this.EnableAppHeaderMenuList();
    this.PlantId = localStorage.getItem("PlantId");
    this.Roleid = localStorage.getItem("RoleID");
    let type = this.activatedRoute.snapshot.params["type"];
    this.GetBisNotification();

    this.form.id = 0;
  }

  GetBisNotification() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.ManageBISNotification(this.jsonParam).subscribe(response => {
      this.BISNotificationList = response;
    });
  }
  PostDelDataByTables(param: any) {
    this.jsonParam = {
      delId: param,
      str: "Notification",
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.PostDelDataByTable(this.jsonParam).subscribe(response => {
      this.DelDataByTables = response;
      console.log(this.DelDataByTables);
      if ((response.success = "DeleteSuccess")) {
        Swal.fire("Great!", "Delete Successfully!", "success");
        this.GetBisNotification();
      }
    });
  }
  EditNotificationMaster(element: any) {
    debugger;
    this.isActiveDiv = true;

    this.form.id = element.id;
    this.form.notification = element.notification;
    this.form.status = element.active;
    this.form.createdBy = element.createdBy;
    this.form.PlantId = element.plantId;
  }

  public NotificationApplication() {
    debugger;
    this.jsonParam = {
      id: this.form.id,
      notification: this.form.notification,
      status: this.form.status,
      createdBy: localStorage.getItem("name"),
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.NotificationApplication(this.jsonParam).subscribe(data => {
      console.log(data);
      this.service.ManageBISNotification(this.jsonParam).subscribe(response => {
        this.BISNotificationList = response;
      });
      Swal.fire("Great!", "Data Created Successfully!", "success");
    });

    this.form.notification = "";
    this.form.status = "";
    this.form.createdBy = "";
    this.form.PlantId = "";
  }

  EnableAppHeaderMenuList() {
    this.service.EnableHeaderMenuList();
  }
  home() {
    this.router.navigate(["/dashboard"]);
  }
  resetForm() {


   
    
    this.form = {
      id: "",
      notification: "",
      status: "",
      createdBy: "",
      PlantId: ""
    };

    
  }
  ngAfterViewInit() {}
  handleClear() {
    this.form.notification = "";
    this.form.status = "";
    this.form.createdBy = "";
    this.form.PlantId = "";
  }
}
function param(param: any, any: any) {
  throw new Error("Function not implemented.");
}
