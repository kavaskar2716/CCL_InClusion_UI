import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild
} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription } from "rxjs";
import {
  ProgressStatus,
  ProgressStatusEnum
} from "src/app/model/progress-status.model";
import { NotificationService } from "src/app/notification.service";
import { SharedService } from "src/app/shared.service";
import { AuthService } from "src/app/_services/auth.service";
import { MatAccordion } from "@angular/material/expansion";
import Swal from "sweetalert2";
@Component({
  selector: "app-manage-mfg",
  templateUrl: "./manage-mfg.component.html",
  styleUrls: ["./manage-mfg.component.css"]
})
export class ManageMfgComponent implements OnInit {
  @ViewChild(MatAccordion) accordion: MatAccordion;
  @Input() public disabled: boolean;
  @Output() public uploadStatus: EventEmitter<ProgressStatus>;
  @ViewChild("inputFile") inputFile: ElementRef;
  public form: {

    mfgPlant: any;
    description: string;
    status: any;
    plantId: any;
  
  };

  fileToUpload: any;
  status: any = "";
  shared: any;
  formgroup: any;
  SharedService: any;
  message: string;
  isActiveDiv: boolean;
  OperatingMasterLists: any;
  fileName: string;
  BISNotificationList: any;
  jsonParam: any = [];
  DelDataByTables: any;
  UserModuleListList: any;
  UserModuleList: any;
  PlantId: string;
  UserName: string;
  //machineDisabled: boolean | undefined;

  constructor(
    private authService: AuthService,
    private service: SharedService,
    private notifyService: NotificationService,
    private activatedRoute: ActivatedRoute,

    private router: Router
  ) {
    this.form = {

      mfgPlant: "",
    description: "",
    status: "",
    plantId: "",
    };
  }

  public subsVar: Subscription | undefined;
  ngOnInit(): void {
    this.EnableAppHeaderMenuList();
    this.PlantId = localStorage.getItem("PlantId");
    
    let type = this.activatedRoute.snapshot.params["type"];
    this.GetBisMfgLists();

    // this.form.userID = 0;
  }
  GetBisMfgLists() {
    this.jsonParam = {
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.ManageMfgLists(this.jsonParam).subscribe(response => {
      this.UserModuleList = response.table;
    });
  }
 
  PostDelDataByTables(param: any) {
    this.jsonParam = {
      delId: param,
      str: "ManageMfg",
      PlantId: localStorage.getItem("PlantId")
    };
    this.service.PostDelDataByTable(this.jsonParam).subscribe(response => {
      this.DelDataByTables = response;
      console.log(this.DelDataByTables);
      if ((response.success = "DeleteSuccess")) {
        Swal.fire("Great!", "Delete Successfully!", "success");
        this.GetBisMfgLists();
      }
    });
  }
  EditUserMaster(element: any) {
    debugger;
    this.isActiveDiv = true;
 
    this.form.mfgPlant = element.mfgName;
    this.form.description = element.description;
    this.form.status = element.status;
    this.form.plantId = element.plantID;
 
  }

  public MfgApplication() {
    debugger;
    this.jsonParam = {
      mfgPlant: this.form.mfgPlant,
      description: this.form.description,
      status: this.form.status,
      
      plantId: this.form.plantId,
     
    };
    this.service.MfgApplication(this.jsonParam).subscribe(data => {
      console.log(data);
      this.service.ManageMfgLists(this.jsonParam).subscribe(response => {
        this.UserModuleList = response.table;
      });
      Swal.fire("Great!", "Data Created Successfully!", "success");
    });

    this.form = {
   
      mfgPlant: "",
    description: "",
    status: "",
    plantId: "",
    };
  }

  EnableAppHeaderMenuList() {
    this.service.EnableHeaderMenuList();
  }
  home() {
    this.router.navigate(["/dashboard"]);
  }
  resetForm() {


   
    
    this.form = {
      mfgPlant: "",
      description: "",
      status: "",
      plantId: "",
    };

    
  }
  ngAfterViewInit() {}
  handleClear() {
    this.form.mfgPlant = "";
    this.form.description = "";
    this.form.status = "";
    this.form.plantId = "";
 
  }
}
