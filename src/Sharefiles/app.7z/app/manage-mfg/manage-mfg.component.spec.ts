import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageMfgComponent } from './manage-mfg.component';

describe('ManageMfgComponent', () => {
  let component: ManageMfgComponent;
  let fixture: ComponentFixture<ManageMfgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageMfgComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageMfgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
