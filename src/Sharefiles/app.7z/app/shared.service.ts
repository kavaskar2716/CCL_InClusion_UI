import { Injectable, EventEmitter } from "@angular/core";
import { Subscription } from "rxjs/internal/Subscription";
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse,
  HttpRequest,
  HttpEvent
} from "@angular/common/http";
import { Observable, of, throwError } from "rxjs";
import { retry, catchError } from "rxjs/operators";
import { Router } from "@angular/router";
import { environment } from "src/environments/environment";
import { encryptLocalStorage } from "./storage";
//operating License//
interface OperatingApplication {
  OLID: any;
  Registration_No: string;
  Product_Category: string;
  Product_Name: string;
  Registered_On: string;
  Valid_Till: string;
  Applicable_Products: string;
  Status: string;
  License_Doc: File | null;
  CreatedBy: string;
  PlantId: string;
  MfgName: string;
}
//PO Reference
interface POApplication {
  POID: any;
  Category: string;
  Product: string;
  PO_Type: any;
  // Lead_Model: string;
  Model_for_BIS: string;
  Supplier_Name: string;
  Quotation_Reference_No: string;
  Quotation_Date: string;
  PO_Reference_No: string;
  PO_Value_in_INR: string;
  PO_Date: string;
  Invoice_No: string;
  Invoice_date: string;
  Payment_Release_Date: string;
  Payment_Value_in_INR: string;
  Balance_Amount: any;
  CreatedBy: string;
  PlantId: string;
  Payment_Term_In_Days :any;
  PO_Remarks :any;
  //Invoice_No:any;
  Invoice_Remarks:any;
  Upload_Quotation: File | null;
  Upload_PO_Reference: File | null;
  Upload_Invoice: File | null;
  MfgPlantID:any;
}
interface QueryApplication {
  QryID: any;
  MfgPlantID: any;
  QryDate: any;
  QueryBy:string;
  Query_Related_To:string;
  QueryTo:string;
  QuerySubject:string;
  Product:string;
  Model_For_BIS:string;
  Inclusion_RequestID:string;
  Query_One:string;
  Query_One_Date: any;
  Query1_Reply_From_Lnv:string;
  Query1_Reply_Date:any;
  Query_Two:string;
  Query_Two_Date: any;
  Query2_Reply_From_Lnv:string;
  Query2_Reply_Date:any;
  Query_Three:string;
  Query_Three_Date: any;
  Query3_Reply_From_Lnv:string;
  Query3_Reply_Date:any;
  CreatedBy:string;
  PlantId: any;
  Query_Status:any;
 
}

//BIS Program
interface BISApplication {
  BISProgramID: any;
  Category: string;
  R_Number: string;
  Product: string;
  Model_For_BIS: string;
  Details: string;
  Test_Request: string;
  India_SS_Date: string;
  Lead_Model: string;
  Series_Model: string;
  FInalize_BIS_Model_Plan: string;
  FInalize_BIS_Model_Plan_Revised: string;
  Finalize_BIS_Model_Actual: string;
  Biz_Approval_PO_Plan: string;
  Biz_Approval_PO_Plan_Revised: string;
  Biz_Approval_PO_Actual: string;
  Sample_Receipt_Plan: string;
  Sample_Receipt_Plan_Revised: string;
  Sample_Receipt_Actual: string;
  Sample_Submission_Lab_Plan: string;
  Sample_Submission_Lab_Plan_Revised: string;
  Sample_Submission_Lab_Actual: string;
  BIS_Lab_Test_Report_Plan: string;
  BIS_Lab_Test_Report_Plan_Revised: string;
  BIS_Lab_Test_Report_Actual: string;
  Letter_Submit_Govt_Plan: string;
  Letter_Submit_Govt_Plan_Revised: string;
  Letter_Submit_Govt_Actual: string;
  BIS_Approved_Plan: string;
  BIS_Approved_Plan_Revised: string;
  BIS_Approved_Actual: string;
  CreatedBy: string;
  PlantId: string;
  MfgPlantID: any;
  Test_Report: string;
  Inclusion_Request_ID: string;
  RGP_Reference: string;
  Adapter: string;
  UMA_DIS: string;
  Battery: string;
  Others: string;
  Upld_Test_Report: File | null;
  Upld_Certificate: File | null;
  Upld_TestRequest: File | null;
  CCLUpload: File | null;
  Upld_RGPReference: File | null;
  Upld_BISProgramOthers: File | null;
}
@Injectable({
  providedIn: "root"
})
export class SharedService {
  invokeAppComponentFunction = new EventEmitter();
  invokeProductCategoryFunction = new EventEmitter();
  public subsVar = Subscription;
  todayNumber: number = Date.now();
  url: string;
  header: any;
  output: any;
  exportDataAsExcel: any;
  constructor(private router: Router, private http: HttpClient) {
    this.url = environment.baseurl;
  }

  UrlhttpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json",
      Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
    })
  };

  handleError(error: HttpErrorResponse) {
    let errorMessage = "Unknown error!";
    if (error.error instanceof ErrorEvent) {
      // Client-side errors
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side errors
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }

  EnableHeaderMenuList() {
    //
    this.invokeAppComponentFunction.emit();
  }

  ProductByCategory(param: string) {
    this.invokeProductCategoryFunction.emit(param);
  }

  //Dashboard//
  getDashboardData(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(this.url + "/BIS/PostDashboard_Data", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

  //MFG Plant//
  GetMfgPlant(): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .get<any>(this.url + "/BIS/GetMFgList", HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

  //Downdload File//

  DownloadFile(param: any): Observable<Blob> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    const _headers = new HttpHeaders().set(
      "Authorization",
      `Bearer ${encryptLocalStorage.getItem("access_token")}`
    );

    debugger;
    return this.http.post(this.url + "/BISProgram/DownloadFile", param, {
      reportProgress: true,
      responseType: "blob",
      headers: _headers
    });
  }

  //Get Product List by fy//
  GetBISProdListByFY(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BIS/PostFilterBy_Fy", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

  //Get BIS Filter By key//
  GetBISKeyFiltersBy_Param(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BIS/PostKeyFiltersBy_Param", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

  GetBISKeyFiltersBy_ParamPO(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    return this.http
      .post<any>(this.url + "/BISProgram/PostFilter_For_BISPOReference", param, HttpToken)
      //
      .pipe(retry(0), catchError(this.handleError));
  }
  GetBISKeyFiltersBy_ModelforbisPO(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BISProgram/PostModelForBIS_Filter_ByProduct", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
  //Product Filter
  ProductByFilters(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(
        this.url + "/BISProgram/PostProductAdvanceFilter",
        param,
        HttpToken
      )
      .pipe(retry(0), catchError(this.handleError));
  }

  ProductFilters(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BIS/PostProductFilters", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
//Product Filter Key list
ProductPOFilters(param: any): Observable<any> {
  const HttpToken = {
    headers: new HttpHeaders({
      "Content-Type": "application/json",
      Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
    })
  };
  //
  return this.http
    .post<any>(this.url + "/BIS/PostBISFilter_KeyList", param, HttpToken)
    .pipe(retry(0), catchError(this.handleError));
}
  //Product Filter Key list
  TradeProductFilters(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BIS/PostFilter_For_BISProgram", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

   //Product Filter Key list
  SearchProductFilterss(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BISProgram/PostProductAdvanceFilter", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
//Product Filter Key list

ProductCommonFilters(param: any): Observable<any> {

  const HttpToken = {

    headers: new HttpHeaders({

      "Content-Type": "application/json",

      Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`

    })

  };

  //

  return this.http

    .post<any>(this.url + "/BIS/PostBISFilter_KeyList", param, HttpToken)

    .pipe(retry(0), catchError(this.handleError));

}
  //product Filter By dynamic query//
  TradingByFilters(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(
        this.url + "/BISProgram/PostProductAdvanceFilter",
        param,
        HttpToken
      )
      .pipe(retry(0), catchError(this.handleError));
  }

  //Create Operating License//
  CreateLicense(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(this.url + "/BIS/PostAddLicense", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

  async submitFileUpload(fd: FormData): Promise<Observable<any>> {
    let returnValue: any;
    const _headers = new HttpHeaders().set(
      "Authorization",
      `Bearer ${sessionStorage.getItem("access_token")}`
    );
    await this.http
      .post<any>(this.url + "/DocumentUpload", fd, { headers: _headers })
      .toPromise()
      .then(data => {
        returnValue = of(data);
      })
      .catch(error => {
        console.error(error);
        returnValue = throwError(new Error(error.message));
      });
    return returnValue;
  }

  public uploadFile(file: Blob): Observable<HttpEvent<void>> {
    const formData = new FormData();
    formData.append("file", file);

    return this.http.request(
      new HttpRequest("POST", this.url + "/BISProgram/Upload", formData, {
        reportProgress: true
      })
    );
  }

  //Bid Program//
  public BISApplication(
    application: BISApplication
  ): Observable<HttpEvent<any>> {
    var formData = new FormData();
    formData.append("BISProgramID", application.BISProgramID);
    formData.append("Category", application.Category);
    formData.append("R_Number", application.R_Number);
    formData.append("Product", application.Product);
    formData.append("Model_For_BIS", application.Model_For_BIS);
    formData.append("Details", application.Details);
    formData.append("Test_Request", application.Test_Request);
    formData.append("India_SS_Date", application.India_SS_Date);
    formData.append("Lead_Model", application.Lead_Model);
    formData.append("Series_Model", application.Series_Model);
    formData.append(
      "FInalize_BIS_Model_Plan",
      application.FInalize_BIS_Model_Plan
    );
    formData.append(
      "FInalize_BIS_Model_Plan_Revised",
      application.FInalize_BIS_Model_Plan_Revised
    );
    formData.append(
      "Finalize_BIS_Model_Actual",
      application.Finalize_BIS_Model_Actual
    );
    formData.append("Biz_Approval_PO_Plan", application.Biz_Approval_PO_Plan);
    formData.append(
      "Biz_Approval_PO_Plan_Revised",
      application.Biz_Approval_PO_Plan_Revised
    );
    formData.append(
      "Biz_Approval_PO_Actual",
      application.Biz_Approval_PO_Actual
    );
    formData.append("Sample_Receipt_Plan", application.Sample_Receipt_Plan);
    formData.append(
      "Sample_Receipt_Plan_Revised",
      application.Sample_Receipt_Plan_Revised
    );
    formData.append("Sample_Receipt_Actual", application.Sample_Receipt_Actual);
    formData.append(
      "Sample_Submission_Lab_Plan",
      application.Sample_Submission_Lab_Plan
    );
    formData.append(
      "Sample_Submission_Lab_Plan_Revised",
      application.Sample_Submission_Lab_Plan_Revised
    );
    formData.append(
      "Sample_Submission_Lab_Actual",
      application.Sample_Submission_Lab_Actual
    );
    formData.append(
      "BIS_Lab_Test_Report_Plan",
      application.BIS_Lab_Test_Report_Plan
    );
    formData.append(
      "BIS_Lab_Test_Report_Plan_Revised",
      application.BIS_Lab_Test_Report_Plan_Revised
    );
    formData.append(
      "BIS_Lab_Test_Report_Actual",
      application.BIS_Lab_Test_Report_Actual
    );
    formData.append(
      "Letter_Submit_Govt_Plan",
      application.Letter_Submit_Govt_Plan
    );
    formData.append(
      "Letter_Submit_Govt_Plan_Revised",
      application.Letter_Submit_Govt_Plan_Revised
    );
    formData.append(
      "Letter_Submit_Govt_Actual",
      application.Letter_Submit_Govt_Actual
    );
    formData.append("BIS_Approved_Plan", application.BIS_Approved_Plan);
    formData.append(
      "BIS_Approved_Plan_Revised",
      application.BIS_Approved_Plan_Revised
    );
    formData.append("BIS_Approved_Actual", application.BIS_Approved_Actual);

    if (application.Upld_Test_Report == null) {
      application.Upld_Test_Report &&
        formData.append("Upld_Test_Report", application.Upld_Test_Report);
    } else {
      var Upld_Test_Report =
        this.todayNumber + "_" + application.Upld_Test_Report.name;
      application.Upld_Test_Report &&
        formData.append(
          "Upld_Test_Report",
          application.Upld_Test_Report,
          Upld_Test_Report
        );
    }

    if (application.Upld_Certificate == null) {
      application.Upld_Certificate &&
        formData.append("Upld_Certificate", application.Upld_Certificate);
    } else {
      var Upld_Certificate =
        this.todayNumber + "_" + application.Upld_Certificate.name;
      application.Upld_Certificate &&
        formData.append(
          "Upld_Certificate",
          application.Upld_Certificate,
          Upld_Certificate
        );
    }

    if (application.Upld_TestRequest == null) {
      application.Upld_TestRequest && formData.append("Upld_TestRequest", application.Upld_TestRequest);
    } else {
      var Upld_TestRequest = this.todayNumber + "_" + application.Upld_TestRequest.name;
      application.Upld_TestRequest &&
        formData.append("Upld_TestRequest", application.Upld_TestRequest, Upld_TestRequest);
    }

    if (application.Upld_RGPReference == null) {
      application.Upld_RGPReference && formData.append("Upld_RGPReference", application.Upld_RGPReference);
    } else {
      var Upld_RGPReference = this.todayNumber + "_" + application.Upld_RGPReference.name;
      application.Upld_RGPReference &&
        formData.append("Upld_RGPReference", application.Upld_RGPReference, Upld_RGPReference);
    }

    if (application.CCLUpload == null) {
      application.CCLUpload && formData.append("CCLUpload", application.CCLUpload);
    } else {
      var CCLUpload = this.todayNumber + "_" + application.CCLUpload.name;
      application.CCLUpload &&
        formData.append("CCLUpload", application.CCLUpload, CCLUpload);
    }

    if (application.Upld_BISProgramOthers == null) {
      application.Upld_BISProgramOthers && formData.append("Upld_BISProgramOthers", application.Upld_BISProgramOthers);
    } else {
      var Upld_BISProgramOthers = this.todayNumber + "_" + application.Upld_BISProgramOthers.name;
      application.Upld_BISProgramOthers &&
        formData.append("Upld_BISProgramOthers", application.Upld_BISProgramOthers, Upld_BISProgramOthers);
    }

    formData.append("Test_Report", application.Test_Report);
    formData.append("Inclusion_Request_ID", application.Inclusion_Request_ID);
    formData.append("RGP_Reference", application.RGP_Reference);
    formData.append("Adapter", application.Adapter);
    formData.append("UMA_DIS", application.UMA_DIS);
    formData.append("Battery", application.Battery);
    formData.append("Others", application.Others);
    formData.append("PlantId", application.PlantId);
    formData.append("CreatedBy", application.CreatedBy);
    formData.append("MfgPlantID", application.MfgPlantID);

    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    const _headers = new HttpHeaders().set(
      "Authorization",
      `Bearer ${encryptLocalStorage.getItem("access_token")}`
    );

    return this.http.request(
      new HttpRequest(
        "POST",
        this.url + "/BISProgram/PostManageBISProgram",
        formData,
        { headers: _headers }
      )
    );
  }

  //Operating license
  public OperatingApplication(
    application: OperatingApplication
  ): Observable<HttpEvent<void>> {
    var formData = new FormData();
    formData.append("OLID", application.OLID);
    formData.append("Registration_No", application.Registration_No);
    formData.append("Product_Category", application.Product_Category);
    formData.append("Product_Name", application.Product_Name);
    formData.append("Registered_On", application.Registered_On);
    formData.append("Valid_Till", application.Valid_Till);
    formData.append("Applicable_Products", application.Applicable_Products);
    formData.append("Status", application.Status);
    formData.append("MfgName", application.MfgName);
    if (application.License_Doc == null) {
      application.License_Doc &&
        formData.append("License_Doc", application.License_Doc);
    } else {
      var License = this.todayNumber + "_" + application.License_Doc.name;
      application.License_Doc &&
        formData.append("License_Doc", application.License_Doc, License);
    }
    formData.append("CreatedBy", application.CreatedBy);
    formData.append("PlantId", application.PlantId);

    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "multipart/form-data",

        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    const _headers = new HttpHeaders().set(
      "Authorization",
      `Bearer ${encryptLocalStorage.getItem("access_token")}`
    );

    return this.http.request(
      new HttpRequest(
        "POST",
        this.url + "/BISProgram/PostManageOperativeLicense",
        formData,
        { headers: _headers }
      )
    );
  }

  //PO Reference
  public POApplication(
    application: POApplication
  ): Observable<HttpEvent<void>> {
    debugger;
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "multipart/form-data",

        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    const _headers = new HttpHeaders().set(
      "Authorization",
      `Bearer ${encryptLocalStorage.getItem("access_token")}`
    );
    var formData = new FormData();
    formData.append("POID", application.POID);
    formData.append("Category", application.Category);
    formData.append("Product", application.Product);
    formData.append("PO_Type", application.PO_Type);
    formData.append("Model_for_BIS", application.Model_for_BIS);
    formData.append("Supplier_Name", application.Supplier_Name);
    formData.append(
      "Quotation_Reference_No",
      application.Quotation_Reference_No
    );
    formData.append("Quotation_Date", application.Quotation_Date);
    formData.append("PO_Reference_No", application.PO_Reference_No);
    formData.append("PO_Value_in_INR", application.PO_Value_in_INR);
    formData.append("PO_Date", application.PO_Date);
    debugger
    formData.append("Invoice_No", application.Invoice_No);
    formData.append("Invoice_date", application.Invoice_date);
    formData.append("Payment_Release_Date", application.Payment_Release_Date);
    formData.append("Payment_Value_in_INR", application.Payment_Value_in_INR);
    formData.append("Balance_Amount", application.Balance_Amount);
    formData.append("CreatedBy", application.CreatedBy);
    formData.append("Payment_Term_In_Days", application.Payment_Term_In_Days);
    formData.append("Invoice_Remarks", application.Invoice_Remarks);
    formData.append("PO_Remarks", application.PO_Remarks);
  //  formData.append("Invoice_No", application.Invoice_No);

    if (application.Upload_Quotation == null) {
      application.Upload_Quotation &&
        formData.append("Upload_Quotation", application.Upload_Quotation);
    } else {
      var Quotation =
        this.todayNumber + "_" + application.Upload_Quotation.name;
      application.Upload_Quotation &&
        formData.append(
          "Upload_Quotation",
          application.Upload_Quotation,
          Quotation
        );
    }

    if (application.Upload_PO_Reference == null) {
      application.Upload_PO_Reference &&
        formData.append("Upload_PO_Reference", application.Upload_PO_Reference);
    } else {
      var PO_Reference =
        this.todayNumber + "_" + application.Upload_PO_Reference.name;
      application.Upload_PO_Reference &&
        formData.append(
          "Upload_PO_Reference",
          application.Upload_PO_Reference,
          PO_Reference
        );
    }

    if (application.Upload_Invoice == null) {
      application.Upload_Invoice &&
        formData.append("Upload_Invoice", application.Upload_Invoice);
    } else {
      var Invoice = this.todayNumber + "_" + application.Upload_Invoice.name;
      application.Upload_Invoice &&
        formData.append("Upload_Invoice", application.Upload_Invoice, Invoice);
    }

    formData.append("PlantId", application.PlantId);
    formData.append("MfgPlantID", application.MfgPlantID);
    debugger;
    return this.http
      .post<any>(this.url + "/BISProgram/PostManagePORef", formData, {
        headers: _headers
      })
      .pipe(retry(0), catchError(this.handleError));
  }

  QueryApplication(form: any): Observable<any> {
    debugger
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BIS/PostManageBISQuery", form, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
  MfgApplication(form: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BIS/PostManageMfgPlant", form, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

  // Create User Module//

  UserApplication(form: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BIS/PostManageBISUser", form, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

  // List User module//
  ManageUserModuleList(): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .get<any>(this.url + "/BIS/GetUserList", HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
  //Create Notification //
  NotificationApplication(form: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BIS/PostManageBISNotification", form, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
//Get Mfg

ManageMfgLists(param: any): Observable<any> {
  const HttpToken = {
    headers: new HttpHeaders({
      "Content-Type": "application/json",
      Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
    })
  };

  return this.http
    .post<any>(this.url + "/BIS/PostMfgPlantList", param, HttpToken)
    .pipe(retry(0), catchError(this.handleError));
}
  //List notification//
  ManageBISNotification(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(this.url + "/BIS/PostBISNotification", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
  //Get Notification Login//
  ManageLoginNotification(): Observable<any> {
    return this.http
      .get<any>(this.url + "/BIS/GetBISNotification")
      .pipe(retry(0), catchError(this.handleError));
  }

  //Chart//
  ManageGetBISChart(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(this.url + "/BIS/PostBISChart", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
  //endchart//
  //dashboardgrantewipplan//

  DataByPlant(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(this.url + "/BIS/PostDashboard_DataByPlant", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
  //Dashboard status data//
  ListStatusData(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(
        this.url + "/BISProgram/PostBISListBy_Status",
        param,
        HttpToken
      )
      .pipe(retry(0), catchError(this.handleError));
  }

  //end//
  //List BIS Program//
  BISProgramMasterList(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(
        this.url + "/BISProgram/PostBISProgramMasterList",
        param,
        HttpToken
      )
      .pipe(retry(0), catchError(this.handleError));
  }

  //Get MFG Modal For BIS//
  GetMfgModalForBis(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(
        this.url + "/BISProgram/PostBISModelForMFGSites",
        param,
        HttpToken
      )
      .pipe(retry(0), catchError(this.handleError));
  }

  //operating fetch data//
  OperatingMasterList(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(this.url + "/BIS/PostOperativeLicense", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

  //List PO Reference//
  POMasterList(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(this.url + "/BIS/PostPOReference", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

    //List PO Reference//
    QueryMasterList(param: any): Observable<any> {
      const HttpToken = {
        headers: new HttpHeaders({
          "Content-Type": "application/json",
          Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
        })
      };
  
      return this.http
        .post<any>(this.url + "/BIS/PostBISQueryList", param, HttpToken)
        .pipe(retry(0), catchError(this.handleError));
    }
    //List PO Reference//
  GetBISInclusionList(param: any): Observable<any> {
      const HttpToken = {
        headers: new HttpHeaders({
          "Content-Type": "application/json",
          Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
        })
      };
  
      return this.http
        .post<any>(this.url + "/BIS/PostBISQueryFilter", param, HttpToken)
        .pipe(retry(0), catchError(this.handleError));
    }

    //BIS Query FIlter By Inclusion//
    GetBISQueryFilterByInclusionID(param: any): Observable<any> {
          const HttpToken = {
            headers: new HttpHeaders({
              "Content-Type": "application/json",
              Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
            })
          };
      
          return this.http
            .post<any>(this.url + "/BIS/PostBISQueryFilterByInclusionID", param, HttpToken)
            .pipe(retry(0), catchError(this.handleError));
        }

    // BIS Query Filter By Product//
    GetBISPOModelList(param: any): Observable<any> {
      const HttpToken = {
        headers: new HttpHeaders({
          "Content-Type": "application/json",
          Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
        })
      };
  
      return this.http
        .post<any>(this.url + "/BIS/PostBISQueryProductFilter", param, HttpToken)
        .pipe(retry(0), catchError(this.handleError));
    }
  GetBISNotification(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(this.url + "/BIS/PostBISNotification", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
  //BIS Granted and Lap test report//
  GrantedandLabMasterList(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(
        this.url + "/BIS/PostBISGrantedAndLabTestReport",
        param,
        HttpToken
      )
      .pipe(retry(0), catchError(this.handleError));
  }

  //Get BIS Granted Report By Days//
  GetBISGrantedReportByDays(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BIS/GetBISGrantedReportByDays", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

  //GET Pending Inclusion//
  GetBISPendingInclusion(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(this.url + "/BIS/PostBISPendingInclusion", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

  //Get Pending Inclusion By Days//
  GetBISPendingInclusionByDays(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(
        this.url + "/BIS/GetBISPendingInclusionByDays",
        param,
        HttpToken
      )
      .pipe(retry(0), catchError(this.handleError));
  }
  //Get lab test Report By Day//
  GetLabTestReportByDays(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BIS/GetLabTestReportByDays", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }

   //Get pending payment count//
   GetPendingPaymentStatusCount(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };
    //
    return this.http
      .post<any>(this.url + "/BIS/PostBISPendingPaymentStatusCount", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
    //Get pending payment count//
    GetPendingPaymentStatusByCount(param: any): Observable<any> {
      const HttpToken = {
        headers: new HttpHeaders({
          "Content-Type": "application/json",
          Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
        })
      };
      //
      return this.http
        .post<any>(this.url + "/BIS/PostBISPendingPaymentStatusWiseList", param, HttpToken)
        .pipe(retry(0), catchError(this.handleError));
    }

     //Get bis query//
     GetBISQueryCount(param: any): Observable<any> {
      const HttpToken = {
        headers: new HttpHeaders({
          "Content-Type": "application/json",
          Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
        })
      };
      //
      return this.http
        .post<any>(this.url + "/BIS/PostBISQueryStatusCount", param, HttpToken)
        .pipe(retry(0), catchError(this.handleError));
    }

         //Get bis query//
         GetBISQueryByCount(param: any): Observable<any> {
          const HttpToken = {
            headers: new HttpHeaders({
              "Content-Type": "application/json",
              Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
            })
          };
          //
          return this.http
            .post<any>(this.url + "/BIS/PostBISQuery_StatusWiseListt", param, HttpToken)
            .pipe(retry(0), catchError(this.handleError));
        }
  //Delete Table in every module//

  PostDelDataByTable(param: any): Observable<any> {
    const HttpToken = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: `Bearer ${encryptLocalStorage.getItem("access_token")}`
      })
    };

    return this.http
      .post<any>(this.url + "/BIS/PostDelDataByTable", param, HttpToken)
      .pipe(retry(0), catchError(this.handleError));
  }
}
