import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AuthGuard } from "./_guards/auth.guard";
import { DashboardComponent } from "./_component/dashboard/dashboard.component";
import { LoginComponent } from "./_component/login/login.component";
import { ProductComponent } from "./product/product.component";
import { ManageMfgComponent } from "./manage-mfg/manage-mfg.component";
import { OperatingLicenseComponent } from "./_component/operating-license/operating-license.component";
import { BisGrantedComponent } from "./_component/bis-granted/bis-granted.component";
import { UserModuleComponent } from "./_component/user-module//user-module.component";
import { BisNotificationComponent } from "./bis-notification//bis-notification.component";
import { CclProgramComponent } from "./_component/ccl-program//ccl-program.component";
import { TrackerComponent } from "./_component/tracker//tracker.component";
import { BisReportComponent } from "./_component/bis-report//bis-report.component";
import { PendingInclusionComponent } from "./_component/pending-inclusion/pending-inclusion.component";
import { BisProgramComponent } from "./_component/bis-program/bis-program.component";
import { PoReferenceComponent } from "./_component/po-reference/po-reference.component";
import { SearchbyproductComponent } from "./_component/searchbyproduct/searchbyproduct.component";
import { TradingDashboardComponent } from "./_component/trading-dashboard/trading-dashboard.component";
import { GuestComponent } from "./_component/guest/guest.component";
import { PendingPaymentComponent } from "./_component/pending-payment/pending-payment.component";
import { BisQueryComponent } from "./_component/bis-query/bis-query.component";

const routes: Routes = [
  {
    path: "dashboard",
    canActivate: [AuthGuard],
    component: DashboardComponent
  },
  {
    path: "bis-report",
    canActivate: [AuthGuard],
    component: BisReportComponent
  },
  {
    path: "bis-query",
    canActivate: [AuthGuard],
    component: BisQueryComponent
  },
  {
    path: "pending-payment",
    canActivate: [AuthGuard],
    component: PendingPaymentComponent
  },
  {
    path: "trading-dashboard",
    canActivate: [AuthGuard],
    component: TradingDashboardComponent
  },
  {
    path: "pending",
    canActivate: [AuthGuard],
    component: PendingInclusionComponent
  },
  {
    path: "manage-mfg",
    canActivate: [AuthGuard],
    component: ManageMfgComponent
  },
  {
    path: "guest",
    canActivate: [AuthGuard],
    component: GuestComponent
  },
  {
    path: "bis-program",
    canActivate: [AuthGuard],
    component: BisProgramComponent
  },
  {
    path: "po-reference",
    canActivate: [AuthGuard],
    component: PoReferenceComponent
  },
  {
    path: "searchbyproduct",
    canActivate: [AuthGuard],
    component: SearchbyproductComponent
  },

  {
    path: "tracker",
    canActivate: [AuthGuard],
    component: TrackerComponent
  },

  {
    path: "bis-notification",
    canActivate: [AuthGuard],
    component: BisNotificationComponent
  },

  {
    path: "operating-license",
    canActivate: [AuthGuard],
    component: OperatingLicenseComponent
  },
  {
    path: "bis-granted",
    canActivate: [AuthGuard],
    component: BisGrantedComponent
  },

  {
    path: "product",
    canActivate: [AuthGuard],
    component: ProductComponent
  },
  {
    path: "user-module",
    canActivate: [AuthGuard],
    component: UserModuleComponent
  },
  {
    path: "ccl-program",
    canActivate: [AuthGuard],
    component: CclProgramComponent
  },
  {
    path: "product/:type",
    canActivate: [AuthGuard],
    component: ProductComponent
  },
  {
    path: "login",
    component: LoginComponent
  },
  { path: "", redirectTo: "/login", pathMatch: "full" },
  { path: "**", redirectTo: "/login" }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
